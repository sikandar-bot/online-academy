<?php
/**
 * Plugin Name: Baba Online Academy
 * Plugin URI:  https://example.com
 * Description: Baba Online Academy - Students, Courses, Fees, Reports & Settings management for computer institutes.
 * Version:     1.2.3
 * Author:      Baba Online Academy
 * Text Domain: baba-online-academy
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ===== Constants =====
define( 'BOA_VERSION', '1.2.3' );
define( 'BOA_PLUGIN_FILE', __FILE__ );
define( 'BOA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BOA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ===== Includes =====
require_once BOA_PLUGIN_DIR . 'class-boa-activator.php';
require_once BOA_PLUGIN_DIR . 'class-boa-db.php';
require_once BOA_PLUGIN_DIR . 'class-boa-assets.php';
require_once BOA_PLUGIN_DIR . 'class-boa-ajax.php';

// ===== Hooks =====
register_activation_hook( __FILE__, array( 'BOA_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'BOA_Activator', 'deactivate' ) );

// ===== Main Plugin Class =====
class Baba_Online_Academy {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );

        // --- نیا: شارٹ کوڈ رجسٹر کریں ---
        add_action( 'init', array( $this, 'register_shortcodes' ) );
        add_action( 'init', array( $this, 'register_cron_events' ) );
        add_action( 'boa_auto_complete_sessions', array( $this, 'handle_auto_complete_sessions' ) );

        // Init helper classes
        BOA_Assets::init();
        BOA_Ajax::init();
    }

    /**
     * Register admin menu and submenus
     */
    public function register_admin_menu() {
        $capability = 'manage_options';
        $slug       = 'baba-online-academy';

        // مین مینو (Dashboard)
        add_menu_page(
            __( 'Baba Online Academy', 'baba-online-academy' ),
            __( 'Baba Academy', 'baba-online-academy' ),
            $capability,
            $slug,
            array( $this, 'render_dashboard_page' ),
            'dashicons-welcome-learn-more',
            26
        );

        // Dashboard
        add_submenu_page(
            $slug,
            __( 'Dashboard', 'baba-online-academy' ),
            __( 'Dashboard', 'baba-online-academy' ),
            $capability,
            'boa-dashboard',
            array( $this, 'render_dashboard_page' )
        );

        // --- نیا: ایڈمیشن ریویوز پیج ---
        add_submenu_page(
            $slug,
            __( 'Admission Reviews', 'baba-online-academy' ),
            __( 'Admission Reviews', 'baba-online-academy' ),
            $capability,
            'boa-admission-reviews',
            array( $this, 'render_admission_reviews_page' )
        );

        add_submenu_page(
            $slug,
            __( 'Live Sessions', 'baba-online-academy' ),
            __( 'Live Sessions', 'baba-online-academy' ),
            $capability,
            'boa-live-sessions',
            array( $this, 'render_live_sessions_page' )
        );

        // Courses
        add_submenu_page(
            $slug,
            __( 'Courses', 'baba-online-academy' ),
            __( 'Courses', 'baba-online-academy' ),
            $capability,
            'boa-courses',
            array( $this, 'render_courses_page' )
        );

        // Students
        add_submenu_page(
            $slug,
            __( 'Students', 'baba-online-academy' ),
            __( 'Students', 'baba-online-academy' ),
            $capability,
            'boa-students',
            array( $this, 'render_students_page' )
        );

        // Fees
        add_submenu_page(
            $slug,
            __( 'Fees', 'baba-online-academy' ),
            __( 'Fees', 'baba-online-academy' ),
            $capability,
            'boa-fees',
            array( $this, 'render_fees_page' )
        );

        // Reports
        add_submenu_page(
            $slug,
            __( 'Reports', 'baba-online-academy' ),
            __( 'Reports', 'baba-online-academy' ),
            $capability,
            'boa-reports',
            array( $this, 'render_reports_page' )
        );

        // Settings
        add_submenu_page(
            $slug,
            __( 'Settings', 'baba-online-academy' ),
            __( 'Settings', 'baba-online-academy' ),
            $capability,
            'boa-settings',
            array( $this, 'render_settings_page' )
        );
    }

    // ===== Page Callbacks =====

    public function render_dashboard_page() {
        $file = BOA_PLUGIN_DIR . 'page-dashboard/page-dashboard.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Baba Online Academy</h1><p>Dashboard page file not found.</p></div>';
        }
    }

    /**
     * نیا: ایڈمیشن ریویو پیج کال بیک
     */
    public function render_admission_reviews_page() {
        // (ہم اس فائل کو بعد میں بنائیں گے)
        $file = BOA_PLUGIN_DIR . 'page-admission-reviews/page-admission-reviews.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Admission Reviews</h1><p>Admission reviews page file not found. (This file will be created next).</p></div>';
        }
    }

    public function render_courses_page() {
        $file = BOA_PLUGIN_DIR . 'page-courses/page-courses.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Courses</h1><p>Courses page file not found.</p></div>';
        }
    }

    public function render_students_page() {
        $file = BOA_PLUGIN_DIR . 'page-students/page-students.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Students</h1><p>Students page file not found.</p></div>';
        }
    }

    public function render_fees_page() {
        $file = BOA_PLUGIN_DIR . 'page-fees/page-fees.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Fees</h1><p>Fees page file not found.</p></div>';
        }
    }

    public function render_reports_page() {
        $file = BOA_PLUGIN_DIR . 'page-reports/page-reports.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Reports</h1><p>Reports page file not found.</p></div>';
        }
    }

    public function render_settings_page() {
        $file = BOA_PLUGIN_DIR . 'page-settings/page-settings.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Settings</h1><p>Settings page file not found.</p></div>';
        }
    }

    public function render_live_sessions_page() {
        $file = BOA_PLUGIN_DIR . 'page-live-sessions/page-live-sessions.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><h1>Live Sessions</h1><p>Live sessions page file not found.</p></div>';
        }
    }

    // ===== شارٹ کوڈز =====

    /**
     * نیا: شارٹ کوڈز رجسٹر کرتا ہے۔
     */
    public function register_shortcodes() {
        add_shortcode( 'boa_admission_form', array( $this, 'render_admission_form_shortcode' ) );
        add_shortcode( 'boa_application_status', array( $this, 'render_application_status_shortcode' ) );
        add_shortcode( 'boa_live_sessions', array( $this, 'render_public_live_sessions_shortcode' ) );
    }

    /**
     * نیا: ایڈمیشن فارم شارٹ کوڈ کو رینڈر کرتا ہے۔
     */
    public function render_admission_form_shortcode( $atts ) {
        // (ہم اس فائل کو بعد میں بنائیں گے)
        $file = BOA_PLUGIN_DIR . 'page-admission-form/page-admission-form.php';
        
        if ( file_exists( $file ) ) {
            // اثاثے (Assets) لوڈ کریں جو اس فارم کے لیے ضروری ہیں
            BOA_Assets::enqueue_public_assets();

            // آؤٹ پٹ بفرنگ (Output Buffering) استعمال کریں تاکہ PHP فائل کا مواد واپس کیا جا سکے
            ob_start();
            include $file;
            return ob_get_clean();
        } else {
            return '<div class="boa-error">Error: Admission form file not found.</div>';
        }
    }

    public function render_application_status_shortcode( $atts ) {
        $file = BOA_PLUGIN_DIR . 'page-application-status/page-application-status.php';

        if ( file_exists( $file ) ) {
            BOA_Assets::enqueue_status_assets();
            ob_start();
            include $file;
            return ob_get_clean();
        }

        return '<div class="boa-error">Error: Application status page file not found.</div>';
    }

    public function render_public_live_sessions_shortcode( $atts ) {
        $file = BOA_PLUGIN_DIR . 'page-live-sessions-public/page-live-sessions-public.php';

        if ( file_exists( $file ) ) {
            BOA_Assets::enqueue_public_live_sessions_assets();
            ob_start();
            include $file;
            return ob_get_clean();
        }

        return '<div class="boa-error">Error: Live sessions page file not found.</div>';
    }

    public function register_cron_events() {
        if ( ! wp_next_scheduled( 'boa_auto_complete_sessions' ) ) {
            wp_schedule_event( time(), 'hourly', 'boa_auto_complete_sessions' );
        }
    }

    public function handle_auto_complete_sessions() {
        BOA_DB::auto_complete_live_sessions();
    }
}

// ===== Helper Functions =====

/**
 * Get currency symbol from settings
 * @return string Currency symbol (e.g., 'PKR', '$', '€')
 */
function boa_get_currency_symbol() {
    $settings = get_option( 'boa_settings', array() );
    $currency = isset( $settings['currency'] ) ? $settings['currency'] : 'PKR';
    
    $symbols = array(
        'USD' => '$',
        'EUR' => '€',
        'GBP' => '£',
        'PKR' => 'PKR',
        'AED' => 'AED'
    );
    
    return isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : $currency;
}

/**
 * Format amount with currency
 * @param float $amount Amount to format
 * @return string Formatted amount with currency
 */
function boa_format_currency( $amount ) {
    $symbol = boa_get_currency_symbol();
    $formatted_amount = number_format( (float) $amount, 2 );
    
    // Get currency code to determine placement
    $settings = get_option( 'boa_settings', array() );
    $currency = isset( $settings['currency'] ) ? $settings['currency'] : 'PKR';
    
    // For PKR and AED, show after amount (e.g., "1,000 PKR")
    // For USD, EUR, GBP, show before amount (e.g., "$1,000.00")
    if ( in_array( $currency, array( 'PKR', 'AED' ) ) ) {
        return $formatted_amount . ' ' . $symbol;
    } else {
        return $symbol . $formatted_amount;
    }
}

// Start plugin
new Baba_Online_Academy();

// ✅ Syntax verified block end
