<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * BABA Online Academy - AJAX Management
 *
 * (2025 BABA ARCHITECT - REFACTOR 9)
 * - apply_fee_discount کو boa_apply_partial_discount سے تبدیل کر دیا گیا ہے۔
 * - یہ اب fee_id اور discount_amount لیتا ہے۔
 * - یہ DB میں فیس کو تقسیم کرنے کے لیے apply_partial_discount کو کال کرتا ہے۔
 */
class BOA_Ajax {

    public static function init() {
        // Students
        add_action( 'wp_ajax_boa_get_students', array( __CLASS__, 'get_students' ) );
        add_action( 'wp_ajax_boa_save_student', array( __CLASS__, 'save_student' ) );
        add_action( 'wp_ajax_boa_delete_student', array( __CLASS__, 'delete_student' ) );

        // Courses
        add_action( 'wp_ajax_boa_get_courses', array( __CLASS__, 'get_courses' ) );
        add_action( 'wp_ajax_boa_save_course', array( __CLASS__, 'save_course' ) );
        add_action( 'wp_ajax_boa_delete_course', array( __CLASS__, 'delete_course' ) );

        // Fees
        add_action( 'wp_ajax_boa_get_fees', array( __CLASS__, 'get_fees' ) );
        add_action( 'wp_ajax_boa_save_fee', array( __CLASS__, 'save_fee' ) );
        add_action( 'wp_ajax_boa_delete_fee', array( __CLASS__, 'delete_fee' ) );
        add_action( 'wp_ajax_boa_upload_receipt', array( __CLASS__, 'upload_receipt' ) );
        
        // --- اپ ڈیٹ: جزوی ڈسکاؤنٹ فنکشن ---
        add_action( 'wp_ajax_boa_apply_partial_discount', array( __CLASS__, 'apply_partial_discount' ) );

        // Reports
        add_action( 'wp_ajax_boa_get_report_data', array( __CLASS__, 'get_report_data' ) );

        // Settings
        add_action( 'wp_ajax_boa_upload_logo', array( __CLASS__, 'upload_logo' ) );
        add_action( 'wp_ajax_boa_save_settings', array( __CLASS__, 'save_settings' ) );
        add_action( 'wp_ajax_boa_manage_category', array( __CLASS__, 'manage_category' ) );

        // --- ایڈمیشن ریویو فنکشنز ---
        add_action( 'wp_ajax_boa_get_pending_admissions', array( __CLASS__, 'get_pending_admissions' ) );
        add_action( 'wp_ajax_boa_approve_admission', array( __CLASS__, 'approve_admission' ) );
        add_action( 'wp_ajax_boa_reject_admission', array( __CLASS__, 'reject_admission' ) );
        add_action( 'wp_ajax_boa_bulk_approve_admissions', array( __CLASS__, 'bulk_approve_admissions' ) );
        add_action( 'wp_ajax_boa_bulk_reject_admissions', array( __CLASS__, 'bulk_reject_admissions' ) );

        // --- پبلک ایڈمیشن فارم فنکشنز ---
        add_action( 'wp_ajax_nopriv_boa_get_course_fee_public', array( __CLASS__, 'get_course_fee_public' ) );
        add_action( 'wp_ajax_boa_get_course_fee_public', array( __CLASS__, 'get_course_fee_public' ) );

        add_action( 'wp_ajax_nopriv_boa_submit_admission_form', array( __CLASS__, 'submit_admission_form' ) );
        add_action( 'wp_ajax_boa_submit_admission_form', array( __CLASS__, 'submit_admission_form' ) );

        // Enhanced features AJAX handlers
        add_action( 'wp_ajax_boa_check_duplicate_submission', array( __CLASS__, 'check_duplicate_submission' ) );
        add_action( 'wp_ajax_nopriv_boa_check_duplicate_submission', array( __CLASS__, 'check_duplicate_submission' ) );
        add_action( 'wp_ajax_boa_check_duplicate_receipt', array( __CLASS__, 'check_duplicate_receipt' ) );
        add_action( 'wp_ajax_nopriv_boa_check_duplicate_receipt', array( __CLASS__, 'check_duplicate_receipt' ) );
        add_action( 'wp_ajax_boa_check_application_status', array( __CLASS__, 'check_application_status' ) );
        add_action( 'wp_ajax_nopriv_boa_check_application_status', array( __CLASS__, 'check_application_status' ) );
        add_action( 'wp_ajax_boa_get_applicant_history', array( __CLASS__, 'get_applicant_history' ) );
        add_action( 'wp_ajax_nopriv_boa_get_applicant_history', array( __CLASS__, 'get_applicant_history' ) );
        add_action( 'wp_ajax_boa_get_student_fees', array( __CLASS__, 'get_student_fees' ) );
        add_action( 'wp_ajax_boa_apply_student_discount', array( __CLASS__, 'apply_student_discount' ) );
        add_action( 'wp_ajax_boa_get_live_sessions', array( __CLASS__, 'get_live_sessions_admin' ) );
        add_action( 'wp_ajax_boa_save_live_session', array( __CLASS__, 'save_live_session' ) );
        add_action( 'wp_ajax_boa_delete_live_session', array( __CLASS__, 'delete_live_session' ) );
        add_action( 'wp_ajax_boa_get_session_attendance', array( __CLASS__, 'get_session_attendance_admin' ) );
        add_action( 'wp_ajax_boa_log_live_attendance', array( __CLASS__, 'log_live_attendance' ) );
        add_action( 'wp_ajax_nopriv_boa_log_live_attendance', array( __CLASS__, 'log_live_attendance' ) );
        add_action( 'wp_ajax_boa_get_public_live_sessions', array( __CLASS__, 'get_public_live_sessions' ) );
        add_action( 'wp_ajax_nopriv_boa_get_public_live_sessions', array( __CLASS__, 'get_public_live_sessions' ) );

        // Export/Import AJAX handlers
        add_action( 'wp_ajax_boa_export_plugin_data', array( __CLASS__, 'export_plugin_data' ) );
        add_action( 'wp_ajax_boa_import_plugin_data', array( __CLASS__, 'import_plugin_data' ) );
        add_action( 'wp_ajax_boa_export_to_excel', array( __CLASS__, 'export_to_excel' ) );
    }

    // ===== Students =====
    public static function get_students() {
        check_ajax_referer( 'boa_students_nonce', 'nonce' );
        $args = array(
            'page'     => isset( $_POST['page'] ) ? max( 1, (int) $_POST['page'] ) : 1,
            'per_page' => isset( $_POST['per_page'] ) ? max( 1, (int) $_POST['per_page'] ) : 10,
            'search'   => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
            'status'   => isset( $_POST['status_filter'] ) ? sanitize_text_field( wp_unslash( $_POST['status_filter'] ) ) : '',
            'course'   => isset( $_POST['course_filter'] ) ? absint( $_POST['course_filter'] ) : '',
            'dateFrom' => isset( $_POST['dateFrom'] ) ? sanitize_text_field( wp_unslash( $_POST['dateFrom'] ) ) : '',
            'dateTo'   => isset( $_POST['dateTo'] ) ? sanitize_text_field( wp_unslash( $_POST['dateTo'] ) ) : '',
        );
        $args['status'] = in_array($args['status'], ['active', 'inactive', 'pending', 'completed']) ? $args['status'] : '';
        if (empty($args['status'])) {
             $args['status__not_in'] = ['pending_review'];
        }
        $data = BOA_DB::get_students( $args );
        wp_send_json_success( array( 'students' => $data['items'], 'page' => $args['page'], 'per_page' => $args['per_page'], 'total' => $data['total'] ) );
    }
    public static function save_student() {
        check_ajax_referer( 'boa_students_nonce', 'nonce' );
        $data = wp_unslash( $_POST );
        if ( empty( $data['name'] ) || empty( $data['email'] ) || empty( $data['course_id'] ) || empty( $data['admission_date'] ) ) {
            wp_send_json_error( array( 'message' => 'Please fill all required fields.' ) );
        }
        $result = BOA_DB::save_student( $data );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
        wp_send_json_success( array( 'message' => 'Student saved successfully.', 'student_id' => $result ) );
    }
    public static function delete_student() {
        check_ajax_referer( 'boa_students_nonce', 'nonce' );
        $student_id = isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : 0;
        if ( $student_id === 0 ) { wp_send_json_error( array( 'message' => 'Invalid Student ID.' ) ); }
        $result = BOA_DB::delete_student( $student_id );
        if ( $result === false ) { wp_send_json_error( array( 'message' => 'Could not delete student.' ) ); }
        wp_send_json_success( array( 'message' => 'Student deleted successfully.' ) );
    }

    // ===== Courses =====
    public static function get_courses() {
        check_ajax_referer( 'boa_courses_nonce', 'nonce' );
        $args = array(
            'page'            => isset( $_POST['page'] ) ? max( 1, (int) $_POST['page'] ) : 1,
            'per_page'        => isset( $_POST['per_page'] ) ? max( 1, (int) $_POST['per_page'] ) : 10,
            'search'          => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
            'status_filter'   => isset( $_POST['status_filter'] ) ? sanitize_text_field( wp_unslash( $_POST['status_filter'] ) ) : '',
            'category_filter' => isset( $_POST['category_filter'] ) ? absint( $_POST['category_filter'] ) : '',
        );
        $data = BOA_DB::get_courses( $args );
        wp_send_json_success( array( 'courses' => $data['items'], 'page' => $args['page'], 'per_page' => $args['per_page'], 'total' => $data['total'] ) );
    }
    public static function save_course() {
        check_ajax_referer( 'boa_courses_nonce', 'nonce' );
        $data = wp_unslash( $_POST );
        
        // Debug logging
        error_log('BOA Course Save - Incoming data: ' . print_r($data, true));
        
        if ( empty( $data['course_name'] ) || empty( $data['category_id'] ) || ! isset( $data['fee_amount'] ) || empty( $data['duration'] ) ) {
            wp_send_json_error( array( 'message' => 'Please fill all required fields.' ) );
        }
        $data['course_id'] = isset( $data['course_id'] ) ? absint( $data['course_id'] ) : 0;
        
        // Debug logging before save
        error_log('BOA Course Save - About to call BOA_DB::save_course');
        
        $result = BOA_DB::save_course( $data );
        
        // Debug logging
        error_log('BOA Course Save - Result: ' . print_r($result, true));
        
        if ( is_wp_error( $result ) ) { 
            $error_message = $result->get_error_message();
            error_log('BOA Course Save - WP Error: ' . $error_message);
            wp_send_json_error( array( 'message' => $error_message ) ); 
        }
        
        if ( $result === false ) {
            error_log('BOA Course Save - Database operation returned false');
            wp_send_json_error( array( 'message' => 'Database operation failed.' ) );
        }
        
        error_log('BOA Course Save - Success');
        wp_send_json_success( array( 'message' => 'Course saved successfully.', 'course_id' => $result ) );
    }
    public static function delete_course() {
        check_ajax_referer( 'boa_courses_nonce', 'nonce' );
        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        if ( $course_id === 0 ) { wp_send_json_error( array( 'message' => 'Invalid Course ID.' ) ); }
        $result = BOA_DB::delete_course( $course_id );
        if ( $result === false ) { wp_send_json_error( array( 'message' => 'Could not delete course.' ) ); }
        wp_send_json_success( array( 'message' => 'Course deleted successfully.' ) );
    }

    // ===== Fees =====
    public static function get_fees() {
        check_ajax_referer( 'boa_fees_nonce', 'nonce' );
        $args = array(
            'page'     => isset( $_POST['page'] ) ? max( 1, (int) $_POST['page'] ) : 1,
            'per_page' => isset( $_POST['per_page'] ) ? max( 1, (int) $_POST['per_page'] ) : 10,
            'search'   => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
            'status'   => isset( $_POST['status_filter'] ) ? sanitize_text_field( wp_unslash( $_POST['status_filter'] ) ) : '',
            'course'   => isset( $_POST['course_filter'] ) ? absint( $_POST['course_filter'] ) : '',
            'dateFrom' => isset( $_POST['dateFrom'] ) ? sanitize_text_field( wp_unslash( $_POST['dateFrom'] ) ) : '',
            'dateTo'   => isset( $_POST['dateTo'] ) ? sanitize_text_field( wp_unslash( $_POST['dateTo'] ) ) : '',
        );
        
        // Debug: Log the filter being applied
        error_log( 'BOA Fees Filter Debug: ' . print_r( $args, true ) );
        
        $data = BOA_DB::get_fees( $args );
        
        // Debug: Log the results
        error_log( 'BOA Fees Results Debug: Total=' . $data['total'] . ', Items=' . count( $data['items'] ) );
        if ( $data['items'] ) {
            $statuses = array_unique( array_column( $data['items'], 'status' ) );
            error_log( 'BOA Fees Statuses found: ' . implode( ', ', $statuses ) );
        }
        
        wp_send_json_success( array( 'fees' => $data['items'], 'page' => $args['page'], 'per_page' => $args['per_page'], 'total' => $data['total'] ) );
    }
    public static function save_fee() {
        check_ajax_referer( 'boa_fees_nonce', 'nonce' );
        $data = wp_unslash( $_POST );
        if ( empty( $data['student_id'] ) || empty( $data['course_id'] ) || !isset($data['amount_paid']) || empty( $data['payment_date'] ) ) {
            wp_send_json_error( array( 'message' => 'Student, Course, Amount Paid, and Payment Date are required.' ) );
        }
        $data['fee_id'] = isset( $data['fee_id'] ) ? absint( $data['fee_id'] ) : 0;
        if ( empty( $data['invoice_id'] ) ) { $data['invoice_id'] = 'INV-' . time(); }
        $result = BOA_DB::save_fee( $data );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
        wp_send_json_success( array( 'message' => 'Fee record saved successfully.', 'fee_id'  => $result ) );
    }
    public static function delete_fee() {
        check_ajax_referer( 'boa_fees_nonce', 'nonce' );
        $fee_id = isset( $_POST['fee_id'] ) ? absint( $_POST['fee_id'] ) : 0;
        if ( $fee_id === 0 ) { wp_send_json_error( array( 'message' => 'Invalid Fee ID.' ) ); }
        $result = BOA_DB::delete_fee( $fee_id );
        if ( $result === false ) { wp_send_json_error( array( 'message' => 'Could not delete fee record.' ) ); }
        wp_send_json_success( array( 'message' => 'Fee record deleted successfully.' ) );
    }
    public static function upload_receipt() {
        check_ajax_referer( 'boa_fees_nonce', 'nonce' );
        if ( empty( $_FILES['receipt_file'] ) ) { wp_send_json_error( array( 'message' => 'No file received' ) ); }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = $_FILES['receipt_file'];
        $uploaded = wp_handle_upload( $file, array( 'test_form' => false ) );
        if ( isset( $uploaded['error'] ) ) { wp_send_json_error( array( 'message' => $uploaded['error'] ) ); }
        wp_send_json_success( array( 'file_url' => $uploaded['url'] ) );
    }

    // ===== Reports =====
    public static function get_report_data() {
        // (یہ فنکشن پہلے جیسا ہی رہے گا)
        check_ajax_referer( 'boa_reports_nonce', 'nonce' );
        $tab = isset( $_POST['tab'] ) ? sanitize_text_field( $_POST['tab'] ) : 'income';
        $filters = isset( $_POST['filters'] ) ? (array) wp_unslash( $_POST['filters'] ) : array();
        $data = array();
        $clean_filters = array(
            'dateFrom' => isset( $filters['dateFrom'] ) ? sanitize_text_field( $filters['dateFrom'] ) : '',
            'dateTo'   => isset( $filters['dateTo'] ) ? sanitize_text_field( $filters['dateTo'] ) : '',
            'course'   => isset( $filters['course'] ) ? absint( $filters['course'] ) : 0,
            'category' => isset( $filters['category'] ) ? absint( $filters['category'] ) : 0,
            'status'   => isset( $filters['status'] ) ? sanitize_text_field( $filters['status'] ) : '',
        );
        switch ( $tab ) {
            case 'income':
                $data['income_trend'] = BOA_DB::get_report_income_trend( $clean_filters );
                $data['course_income_summary'] = BOA_DB::get_report_course_income_summary( $clean_filters );
                $data['income_details'] = BOA_DB::get_report_income_details( $clean_filters );
                break;
            case 'students':
                $data['student_stats'] = BOA_DB::get_student_summary_stats();
                $data['students_by_course'] = BOA_DB::get_student_course_snapshot_stats();
                $data['student_list'] = BOA_DB::get_students( $clean_filters );
                break;
            case 'fees':
                $data['fee_stats'] = BOA_DB::get_fee_summary_stats();
                $data['fee_status_snapshot'] = BOA_DB::get_fee_status_snapshot();
                $data['fee_list'] = BOA_DB::get_fees( $clean_filters );
                break;
            case 'courses':
                $data['course_profitability'] = BOA_DB::get_report_course_income_summary( $clean_filters );
                $data['top_courses'] = BOA_DB::get_report_course_income_summary( $clean_filters );
                $data['course_list'] = array();
                break;
        }
        wp_send_json_success( $data );
    }

    // ===== Settings & Categories =====
    public static function upload_logo() {
        check_ajax_referer( 'boa_settings_nonce', 'nonce' );
        if ( empty( $_FILES['logo_file'] ) ) { wp_send_json_error( array( 'message' => 'No file received' ) ); }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = $_FILES['logo_file'];
        $uploaded = wp_handle_upload( $file, array( 'test_form' => false ) );
        if ( isset( $uploaded['error'] ) ) { wp_send_json_error( array( 'message' => $uploaded['error'] ) ); }
        $settings = BOA_DB::get_settings(); $settings['logo_url'] = $uploaded['url'];
        BOA_DB::save_settings( $settings );
        wp_send_json_success( array( 'logo_url' => $uploaded['url'] ) );
    }
    public static function save_settings() {
        check_ajax_referer( 'boa_settings_nonce', 'nonce' );
        $section = isset( $_POST['section'] ) ? sanitize_text_field( wp_unslash( $_POST['section'] ) ) : 'general';
        $data    = isset( $_POST['data'] ) ? (array) wp_unslash( $_POST['data'] ) : array();
        $settings = BOA_DB::get_settings();
        foreach ( $data as $key => $value ) { $settings[ $key ] = $value; }
        BOA_DB::save_settings( $settings );
        wp_send_json_success( array( 'settings' => $settings, 'section'  => $section ) );
    }
    public static function manage_category() {
        check_ajax_referer( 'boa_settings_nonce', 'nonce' );
        $operation = isset( $_POST['operation'] ) ? sanitize_text_field( wp_unslash( $_POST['operation'] ) ) : '';
        $name      = isset( $_POST['category_name'] ) ? sanitize_text_field( wp_unslash( $_POST['category_name'] ) ) : '';
        $id        = isset( $_POST['category_id'] ) ? absint( $_POST['category_id'] ) : 0;
        $result = false;
        if ( 'add' === $operation ) { $result = BOA_DB::add_category( $name ); }
        elseif ( 'edit' === $operation && $id > 0 ) { $result = BOA_DB::update_category( $id, $name ); }
        elseif ( 'delete' === $operation && $id > 0 ) { $result = BOA_DB::delete_category( $id ); }
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
        if ( $result === false ) { wp_send_json_error( array( 'message' => 'Invalid operation or data.' ) ); }
        $categories = BOA_DB::get_categories();
        wp_send_json_success( array( 'categories' => $categories ) );
    }

    // ===========================================
    // ===== اپ ڈیٹ شدہ فنکشنز (Admission & Discount) =====
    // ===========================================

    /**
     * پبلک فنکشن
     * کورس کی فیس فرنٹ-اینڈ فارم کو بھیجتا ہے۔
     */
    public static function get_course_fee_public() {
        check_ajax_referer( 'boa_public_nonce', 'nonce' );
        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        if ( $course_id === 0 ) {
            wp_send_json_error( array( 'message' => 'Invalid course.' ) );
        }
        $fee = BOA_DB::get_course_fee_public( $course_id );
        wp_send_json_success( array( 'fee_amount' => $fee ) );
    }

    /**
     * پبلک فنکشن
     * فرنٹ-اینڈ ایڈمیشن فارم کو سبمٹ کرتا ہے۔
     */
    public static function submit_admission_form() {
        check_ajax_referer( 'boa_public_nonce', 'nonce' );

        $data            = wp_unslash( $_POST );
        $required_fields = array( 'name', 'email', 'phone', 'city', 'course_id', 'amount_paid' );

        foreach ( $required_fields as $field ) {
            if ( empty( $data[ $field ] ) ) {
                wp_send_json_error( array( 'message' => "Error: Field '$field' is required." ) );
            }
        }

        $email     = sanitize_email( $data['email'] );
        $phone     = sanitize_text_field( $data['phone'] );
        $course_id = absint( $data['course_id'] );

        if ( $course_id === 0 ) {
            wp_send_json_error( array( 'message' => 'Invalid course selection.' ) );
        }

        if ( BOA_DB::student_exists_for_course( $email, $phone, $course_id ) ) {
            wp_send_json_error( array( 'message' => __( 'This student already exists for the selected course.', 'baba-online-academy' ) ) );
        }

        $submission_conflict = BOA_DB::get_form_submission_conflict( $email, $phone, $course_id );
        if ( $submission_conflict === 'email' ) {
            wp_send_json_error( array( 'message' => __( 'This email has already been used for this course.', 'baba-online-academy' ) ) );
        } elseif ( $submission_conflict === 'phone' ) {
            wp_send_json_error( array( 'message' => __( 'This phone number has already been used for this course.', 'baba-online-academy' ) ) );
        }

        if ( empty( $_FILES['screenshot_files'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Please upload at least one payment receipt.', 'baba-online-academy' ) ) );
        }

        $receipt_files = self::normalize_files_array( $_FILES['screenshot_files'] );
        if ( empty( $receipt_files ) ) {
            wp_send_json_error( array( 'message' => __( 'Please upload at least one payment receipt.', 'baba-online-academy' ) ) );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $uploaded_files = array();
        foreach ( $receipt_files as $file ) {
            if ( empty( $file['name'] ) || ( isset( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) ) {
                continue;
            }
            if ( empty( $file['tmp_name'] ) ) {
                continue;
            }

            $upload = wp_handle_upload( $file, array( 'test_form' => false ) );
            if ( isset( $upload['error'] ) ) {
                self::cleanup_uploaded_files( $uploaded_files );
                wp_send_json_error( array( 'message' => $upload['error'] ) );
            }

            $file_path = isset( $upload['file'] ) ? $upload['file'] : '';
            $file_hash = ( $file_path && file_exists( $file_path ) ) ? hash_file( 'sha256', $file_path ) : '';

            $uploaded_files[] = array(
                'url'  => $upload['url'],
                'path' => $file_path,
                'name' => $file['name'],
                'type' => $file['type'],
                'hash' => $file_hash,
            );
        }

        if ( empty( $uploaded_files ) ) {
            wp_send_json_error( array( 'message' => __( 'All uploaded files were invalid. Please try again.', 'baba-online-academy' ) ) );
        }

        $course_fee    = isset( $data['course_fee'] ) ? (float) $data['course_fee'] : 0;
        $amount_paid   = (float) $data['amount_paid'];
        $remaining_fee = max( 0, $course_fee - $amount_paid );

        if ( $amount_paid <= 0 ) {
            self::cleanup_uploaded_files( $uploaded_files );
            wp_send_json_error( array( 'message' => __( 'Amount paid must be greater than zero.', 'baba-online-academy' ) ) );
        }

        if ( $course_fee > 0 && $amount_paid > $course_fee ) {
            self::cleanup_uploaded_files( $uploaded_files );
            wp_send_json_error( array( 'message' => __( 'Amount paid cannot exceed the course fee.', 'baba-online-academy' ) ) );
        }

        if ( $remaining_fee > 0 && empty( $data['next_due_date'] ) ) {
            self::cleanup_uploaded_files( $uploaded_files );
            wp_send_json_error( array( 'message' => __( 'Next due date is required for remaining fees.', 'baba-online-academy' ) ) );
        }

        $student_data = array(
            'name'           => sanitize_text_field( $data['name'] ),
            'email'          => $email,
            'phone'          => $phone,
            'city'           => sanitize_text_field( $data['city'] ),
            'course_id'      => $course_id,
            'admission_date' => current_time( 'Y-m-d' ),
            'status'         => 'pending_review',
        );

        $student_id = BOA_DB::save_student( $student_data );
        if ( is_wp_error( $student_id ) ) {
            self::cleanup_uploaded_files( $uploaded_files );
            wp_send_json_error( array( 'message' => $student_id->get_error_message() ) );
        }

        $invoice_id  = 'INV-' . time();
        $primary_fee = array(
            'student_id'   => $student_id,
            'course_id'    => $course_id,
            'amount_due'   => $amount_paid,
            'amount_paid'  => $amount_paid,
            'due_date'     => current_time( 'Y-m-d' ),
            'payment_date' => current_time( 'Y-m-d' ),
            'status'       => 'pending_review',
            'invoice_id'   => $invoice_id . '-P1',
            'receipt_url'  => $uploaded_files[0]['url'],
        );

        $primary_fee_id = BOA_DB::save_fee( $primary_fee );
        if ( is_wp_error( $primary_fee_id ) ) {
            self::cleanup_uploaded_files( $uploaded_files );
            BOA_DB::delete_student( $student_id );
            wp_send_json_error( array( 'message' => $primary_fee_id->get_error_message() ) );
        }

        foreach ( $uploaded_files as $receipt ) {
            BOA_DB::add_fee_receipt(
                $primary_fee_id,
                $student_id,
                $receipt['url'],
                $receipt['name'],
                $receipt['type'],
                $receipt['hash']
            );
        }

        if ( $remaining_fee > 0 ) {
            $pending_fee_data = array(
                'student_id'   => $student_id,
                'course_id'    => $course_id,
                'amount_due'   => $remaining_fee,
                'amount_paid'  => 0.00,
                'due_date'     => sanitize_text_field( $data['next_due_date'] ),
                'payment_date' => null,
                'status'       => 'pending',
                'invoice_id'   => $invoice_id . '-P2',
                'receipt_url'  => '',
            );

            $pending_fee_result = BOA_DB::save_fee( $pending_fee_data );
            if ( is_wp_error( $pending_fee_result ) ) {
                BOA_DB::delete_fee( $primary_fee_id );
                BOA_DB::delete_student( $student_id );
                self::cleanup_uploaded_files( $uploaded_files );
                wp_send_json_error( array( 'message' => $pending_fee_result->get_error_message() ) );
            }
        }

        $submission_id = BOA_DB::add_form_submission( array(
            'student_id'            => $student_id,
            'email'                 => $email,
            'phone'                 => $phone,
            'course_id'             => $course_id,
            'name'                  => $data['name'],
            'status'                => 'pending_review',
            'discount_amount'       => $data['discount_amount'] ?? 0,
            'discount_reason'       => $data['discount_reason'] ?? '',
            'receipt_file_hash'     => $uploaded_files[0]['hash'],
            'receipt_original_name' => $uploaded_files[0]['name'],
        ) );

        if ( is_wp_error( $submission_id ) ) {
            BOA_DB::delete_fee( $primary_fee_id );
            BOA_DB::delete_student( $student_id );
            self::cleanup_uploaded_files( $uploaded_files );
            wp_send_json_error( array( 'message' => $submission_id->get_error_message() ) );
        }

        $tracking_token = BOA_DB::get_submission_tracking_token( $submission_id );

        wp_send_json_success( array(
            'message'  => __( 'Admission form submitted successfully. We will contact you soon.', 'baba-online-academy' ),
            'receipts' => wp_list_pluck( $uploaded_files, 'url' ),
            'tracking_token' => $tracking_token,
        ) );
    }

    /**
     * اپ ڈیٹ: ایڈمن فنکشن
     * فیس کو جزوی ڈسکاؤنٹ کے طور پر نشان زد کرتا ہے۔
     */
    public static function apply_partial_discount() {
        check_ajax_referer( 'boa_fees_nonce', 'nonce' );
        
        $fee_id = isset( $_POST['fee_id'] ) ? absint( $_POST['fee_id'] ) : 0;
        $discount_amount = isset( $_POST['discount_amount'] ) ? (float) $_POST['discount_amount'] : 0;

        if ( $fee_id === 0 || $discount_amount <= 0 ) {
            wp_send_json_error( array( 'message' => 'Invalid Fee ID or Discount Amount.' ) );
        }

        $result = BOA_DB::apply_partial_discount( $fee_id, $discount_amount );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        if ( $result === false ) {
            wp_send_json_error( array( 'message' => 'Could not apply partial discount.' ) );
        }

        wp_send_json_success( array( 'message' => 'Fee successfully discounted.' ) );
    }

    /**
     * ایڈمن فنکشن
     * زیرِ جائزہ داخلے حاصل کرتا ہے۔
     */
    public static function get_pending_admissions() {
        check_ajax_referer( 'boa_admin_review_nonce', 'nonce' );
        $args = array(
            'page'     => isset( $_POST['page'] ) ? max( 1, (int) $_POST['page'] ) : 1,
            'per_page' => isset( $_POST['per_page'] ) ? max( 1, (int) $_POST['per_page'] ) : 10,
        );
        $data = BOA_DB::get_pending_admissions( $args );
        wp_send_json_success( array( 'admissions' => $data['items'], 'page' => $args['page'], 'per_page' => $args['per_page'], 'total' => $data['total'] ) );
    }

    /**
     * ایڈمن فنکشن
     * داخلے کو منظور کرتا ہے۔
     */
    public static function approve_admission() {
        check_ajax_referer( 'boa_admin_review_nonce', 'nonce' );
        $fee_id = isset( $_POST['fee_id'] ) ? absint( $_POST['fee_id'] ) : 0;
        $student_id = isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : 0;
        $result = self::approve_admission_record( $fee_id, $student_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
        wp_send_json_success( array( 'message' => 'Admission approved successfully.' ) );
    }

    /**
     * ایڈمن فنکشن
     * داخلے کو مسترد کرتا ہے۔
     */
    public static function reject_admission() {
        check_ajax_referer( 'boa_admin_review_nonce', 'nonce' );
        $fee_id = isset( $_POST['fee_id'] ) ? absint( $_POST['fee_id'] ) : 0;
        $student_id = isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : 0;
        $result = self::reject_admission_record( $fee_id, $student_id );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
        wp_send_json_success( array( 'message' => 'Admission rejected and data removed.' ) );
    }

    /**
     * Bulk approve pending admissions
     */
    public static function bulk_approve_admissions() {
        check_ajax_referer( 'boa_admin_review_nonce', 'nonce' );
        $items = self::parse_bulk_admission_items();

        if ( empty( $items ) ) {
            wp_send_json_error( array( 'message' => 'Please select at least one application.' ) );
        }

        $processed = 0;
        $failed    = array();

        foreach ( $items as $item ) {
            $fee_id     = isset( $item['fee_id'] ) ? absint( $item['fee_id'] ) : 0;
            $student_id = isset( $item['student_id'] ) ? absint( $item['student_id'] ) : 0;

            $result = self::approve_admission_record( $fee_id, $student_id );
            if ( is_wp_error( $result ) ) {
                $failed[] = array(
                    'fee_id'     => $fee_id,
                    'student_id' => $student_id,
                    'message'    => $result->get_error_message(),
                );
            } else {
                $processed++;
            }
        }

        if ( $processed === 0 ) {
            wp_send_json_error( array(
                'message' => 'No applications were approved. Please try again.',
                'failed'  => $failed,
            ) );
        }

        $message = sprintf(
            _n( '%d application approved.', '%d applications approved.', $processed, 'baba-online-academy' ),
            $processed
        );

        if ( ! empty( $failed ) ) {
            $message .= ' Some applications could not be processed.';
        }

        wp_send_json_success( array(
            'message'   => $message,
            'processed' => $processed,
            'failed'    => $failed,
        ) );
    }

    /**
     * Bulk reject pending admissions
     */
    public static function bulk_reject_admissions() {
        check_ajax_referer( 'boa_admin_review_nonce', 'nonce' );
        $items = self::parse_bulk_admission_items();

        if ( empty( $items ) ) {
            wp_send_json_error( array( 'message' => 'Please select at least one application.' ) );
        }

        $processed = 0;
        $failed    = array();

        foreach ( $items as $item ) {
            $fee_id     = isset( $item['fee_id'] ) ? absint( $item['fee_id'] ) : 0;
            $student_id = isset( $item['student_id'] ) ? absint( $item['student_id'] ) : 0;

            $result = self::reject_admission_record( $fee_id, $student_id );
            if ( is_wp_error( $result ) ) {
                $failed[] = array(
                    'fee_id'     => $fee_id,
                    'student_id' => $student_id,
                    'message'    => $result->get_error_message(),
                );
            } else {
                $processed++;
            }
        }

        if ( $processed === 0 ) {
            wp_send_json_error( array(
                'message' => 'No applications were rejected. Please try again.',
                'failed'  => $failed,
            ) );
        }

        $message = sprintf(
            _n( '%d application rejected.', '%d applications rejected.', $processed, 'baba-online-academy' ),
            $processed
        );

        if ( ! empty( $failed ) ) {
            $message .= ' Some applications could not be processed.';
        }

        wp_send_json_success( array(
            'message'   => $message,
            'processed' => $processed,
            'failed'    => $failed,
        ) );
    }

    /**
     * Decode bulk action payload from request
     *
     * @return array
     */
    private static function parse_bulk_admission_items() {
        $items = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : array();

        if ( is_string( $items ) ) {
            $decoded = json_decode( $items, true );
            if ( json_last_error() === JSON_ERROR_NONE ) {
                $items = $decoded;
            }
        }

        return is_array( $items ) ? $items : array();
    }

    /**
     * Approve a single admission record
     *
     * @param int $fee_id
     * @param int $student_id
     * @return true|WP_Error
     */
    private static function approve_admission_record( $fee_id, $student_id ) {
        global $wpdb;

        if ( $fee_id === 0 || $student_id === 0 ) {
            return new WP_Error( 'invalid_data', 'Invalid data provided.' );
        }

        $student_update = $wpdb->update(
            $wpdb->prefix . 'boa_students',
            array( 'status' => 'active' ),
            array( 'student_id' => $student_id ),
            array( '%s' ),
            array( '%d' )
        );

        $fee_update = $wpdb->update(
            $wpdb->prefix . 'boa_fees',
            array( 'status' => 'paid' ),
            array( 'fee_id' => $fee_id ),
            array( '%s' ),
            array( '%d' )
        );

        if ( $student_update === false || $fee_update === false ) {
            return new WP_Error( 'db_error', 'Could not update admission record.' );
        }

        BOA_DB::update_form_submission_status_by_student( $student_id, 'approved' );

        return true;
    }

    /**
     * Reject a single admission record
     *
     * @param int $fee_id
     * @param int $student_id
     * @return true|WP_Error
     */
    private static function reject_admission_record( $fee_id, $student_id ) {
        global $wpdb;

        if ( $fee_id === 0 || $student_id === 0 ) {
            return new WP_Error( 'invalid_data', 'Invalid data provided.' );
        }

        BOA_DB::update_form_submission_status_by_student( $student_id, 'rejected' );
        $student_deleted = BOA_DB::delete_student( $student_id );
        $fee_deleted     = BOA_DB::delete_fee( $fee_id );

        $wpdb->delete(
            $wpdb->prefix . 'boa_fees',
            array( 'student_id' => $student_id, 'status' => 'pending' ),
            array( '%d', '%s' )
        );
        $wpdb->delete(
            $wpdb->prefix . 'boa_fees',
            array( 'student_id' => $student_id, 'status' => 'discounted' ),
            array( '%d', '%s' )
        );

        if ( $student_deleted === false || $fee_deleted === false ) {
            return new WP_Error( 'db_error', 'Could not remove admission record.' );
        }

        return true;
    }

    private static function format_submission_status( $status ) {
        switch ( $status ) {
            case 'approved':
                return __( 'Approved', 'baba-online-academy' );
            case 'rejected':
                return __( 'Rejected', 'baba-online-academy' );
            case 'pending_review':
            default:
                return __( 'Pending Review', 'baba-online-academy' );
        }
    }

    // ===== ENHANCED FEATURES =====
    
    /**
     * Check if student already submitted form for this course
     */
    public static function check_duplicate_submission() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
        $phone = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        
        if ( $course_id === 0 || ( empty( $email ) && empty( $phone ) ) ) {
            wp_send_json_error( array( 'message' => 'Invalid parameters.' ) );
        }
        
        if ( BOA_DB::student_exists_for_course( $email, $phone, $course_id ) ) {
            wp_send_json_success( array(
                'exists'  => true,
                'message' => __( 'A student with these details already exists for this course.', 'baba-online-academy' ),
                'type'    => 'student',
            ) );
        }

        $conflict = BOA_DB::get_form_submission_conflict( $email, $phone, $course_id );
        if ( $conflict ) {
            $message = $conflict === 'email'
                ? __( 'This email has already been used for this course.', 'baba-online-academy' )
                : __( 'This phone number has already been used for this course.', 'baba-online-academy' );

            wp_send_json_success( array(
                'exists'  => true,
                'message' => $message,
                'type'    => $conflict,
            ) );
        }

        wp_send_json_success( array( 'exists' => false ) );
    }
    
    /**
     * Check if receipt file is already uploaded
     */
    public static function check_duplicate_receipt() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $file_hash = isset( $_POST['file_hash'] ) ? sanitize_text_field( $_POST['file_hash'] ) : '';
        $submission_id = isset( $_POST['submission_id'] ) ? absint( $_POST['submission_id'] ) : 0;
        
        if ( empty( $file_hash ) ) {
            wp_send_json_error( array( 'message' => 'File hash required.' ) );
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'boa_form_submissions';
        $receipts_table = $wpdb->prefix . 'boa_fee_receipts';
        
        $query = "SELECT submission_id FROM $table_name WHERE receipt_file_hash = %s";
        $params = array( $file_hash );
        
        if ( $submission_id > 0 ) {
            $query .= " AND submission_id != %d";
            $params[] = $submission_id;
        }
        
        $form_exists = $wpdb->get_var( $wpdb->prepare( $query, $params ) );
        $receipt_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT receipt_id FROM $receipts_table WHERE file_hash = %s LIMIT 1",
                $file_hash
            )
        );

        $exists = ! empty( $form_exists ) || ! empty( $receipt_exists );
        wp_send_json_success( array( 'exists' => !empty( $exists ) ) );
    }
    
    /**
     * Public application status checker
     */
    public static function check_application_status() {
        check_ajax_referer( 'boa_public_nonce', 'nonce' );

        $tracking_token = isset( $_POST['tracking_token'] ) ? sanitize_text_field( wp_unslash( $_POST['tracking_token'] ) ) : '';
        $email          = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
        $phone          = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';

        if ( empty( $tracking_token ) || ( empty( $email ) && empty( $phone ) ) ) {
            wp_send_json_error( array( 'message' => __( 'Tracking code along with email or phone is required.', 'baba-online-academy' ) ) );
        }

        $submission = BOA_DB::get_submission_status_public( $tracking_token, $email, $phone );
        if ( empty( $submission ) ) {
            wp_send_json_error( array( 'message' => __( 'No application found for the provided details.', 'baba-online-academy' ) ) );
        }

        $status_label = self::format_submission_status( $submission['status'] );
        $timeline     = array();

        if ( ! empty( $submission['submission_date'] ) ) {
            $timeline[] = array(
                'label' => __( 'Submitted', 'baba-online-academy' ),
                'date'  => $submission['submission_date'],
            );
        }

        if ( ! empty( $submission['status_updated_at'] ) ) {
            $timeline[] = array(
                'label' => $status_label,
                'date'  => $submission['status_updated_at'],
            );
        }

        wp_send_json_success( array(
            'status'            => $submission['status'],
            'status_label'      => $status_label,
            'status_notes'      => $submission['status_notes'],
            'status_updated_at' => $submission['status_updated_at'],
            'submission_date'   => $submission['submission_date'],
            'course_name'       => $submission['course_name'],
            'tracking_token'    => $submission['tracking_token'],
            'timeline'          => $timeline,
        ) );
    }

    public static function get_applicant_history() {
        $nonce_field = isset( $_POST['nonce'] ) ? 'nonce' : '_wpnonce';
        check_ajax_referer( isset( $_POST['is_public'] ) ? 'boa_public_nonce' : 'boa_ajax_nonce', $nonce_field );

        $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
        $phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';

        if ( empty( $email ) && empty( $phone ) ) {
            wp_send_json_error( array( 'message' => __( 'Email or phone is required.', 'baba-online-academy' ) ) );
        }

        $history = BOA_DB::get_applicant_history( $email, $phone );

        wp_send_json_success( array(
            'submissions' => $history['submissions'],
            'enrollments' => $history['enrollments'],
        ) );
    }
    
    /**
     * Get student fees information for discount modal
     */
    public static function get_student_fees() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $student_id = isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : 0;
        
        if ( $student_id === 0 ) {
            wp_send_json_error( array( 'message' => 'Invalid student ID.' ) );
        }
        
        $fee_data = BOA_DB::get_student_pending_fees( $student_id );
        
        if ( ! $fee_data ) {
            wp_send_json_error( array( 'message' => 'No fee data found.' ) );
        }
        
        // Format currency
        $formatted_data = array(
            'total_due' => boa_format_currency( $fee_data['total_due'] ),
            'total_paid' => boa_format_currency( $fee_data['total_paid'] ),
            'pending_amount' => boa_format_currency( $fee_data['pending_amount'] ),
            'pending_amount_numeric' => floatval( $fee_data['pending_amount'] )
        );
        
        wp_send_json_success( $formatted_data );
    }
    
    /**
     * Apply discount to student
     */
    public static function apply_student_discount() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $student_id = isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : 0;
        $discount_amount = isset( $_POST['discount_amount'] ) ? floatval( $_POST['discount_amount'] ) : 0;
        $discount_reason = isset( $_POST['discount_reason'] ) ? sanitize_textarea_field( $_POST['discount_reason'] ) : '';
        
        if ( $student_id === 0 || $discount_amount <= 0 || empty( $discount_reason ) ) {
            wp_send_json_error( array( 'message' => 'Please provide valid discount details.' ) );
        }
        
        $result = BOA_DB::apply_student_discount( $student_id, $discount_amount, $discount_reason );
        
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
        
        wp_send_json_success( array( 
            'message' => 'Discount applied successfully!',
            'discount_applied' => $result['discount_applied'],
            'records_updated' => $result['records_updated']
        ) );
    }

    // ===== Live Sessions Management =====

    public static function get_live_sessions_admin() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );

        $args = array(
            'page'      => isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1,
            'per_page'  => isset( $_POST['per_page'] ) ? max( 1, absint( $_POST['per_page'] ) ) : 10,
            'course_id' => isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0,
            'status'    => sanitize_text_field( $_POST['status'] ?? '' ),
            'search'    => sanitize_text_field( $_POST['search'] ?? '' ),
            'upcoming'  => ! empty( $_POST['upcoming'] ),
        );

        $sessions = BOA_DB::get_live_sessions( $args );
        wp_send_json_success( $sessions );
    }

    public static function save_live_session() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );

        $data = array(
            'session_id'       => isset( $_POST['session_id'] ) ? absint( $_POST['session_id'] ) : 0,
            'course_id'        => isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : null,
            'session_title'    => sanitize_text_field( $_POST['session_title'] ?? '' ),
            'platform'         => sanitize_text_field( $_POST['platform'] ?? 'custom' ),
            'join_url'         => $_POST['join_url'] ?? '',
            'host_url'         => $_POST['host_url'] ?? '',
            'start_time'       => sanitize_text_field( $_POST['start_time'] ?? '' ),
            'end_time'         => $_POST['end_time'] ?? '',
            'duration_minutes' => isset( $_POST['duration_minutes'] ) ? absint( $_POST['duration_minutes'] ) : null,
            'instructor_name'  => sanitize_text_field( $_POST['instructor_name'] ?? '' ),
            'status'           => sanitize_text_field( $_POST['status'] ?? 'scheduled' ),
        );

        if ( empty( $data['session_title'] ) || empty( $data['start_time'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Session title and start time are required.', 'baba-online-academy' ) ) );
        }

        $result = BOA_DB::save_live_session( $data );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => __( 'Session saved successfully.', 'baba-online-academy' ), 'session_id' => $result ) );
    }

    public static function delete_live_session() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $session_id = isset( $_POST['session_id'] ) ? absint( $_POST['session_id'] ) : 0;

        if ( $session_id === 0 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid session ID.', 'baba-online-academy' ) ) );
        }

        $deleted = BOA_DB::delete_live_session( $session_id );
        if ( $deleted === false ) {
            wp_send_json_error( array( 'message' => __( 'Unable to delete session.', 'baba-online-academy' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Session deleted.', 'baba-online-academy' ) ) );
    }

    public static function get_session_attendance_admin() {
        check_ajax_referer( 'boa_ajax_nonce', 'nonce' );
        $session_id = isset( $_POST['session_id'] ) ? absint( $_POST['session_id'] ) : 0;

        if ( $session_id === 0 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid session ID.', 'baba-online-academy' ) ) );
        }

        $records = BOA_DB::get_session_attendance( $session_id );
        wp_send_json_success( array( 'records' => $records ) );
    }

    public static function log_live_attendance() {
        $nonce_field = isset( $_POST['nonce'] ) ? 'nonce' : '_wpnonce';
        $nonce_value = isset( $_POST[ $nonce_field ] ) ? $_POST[ $nonce_field ] : '';
        if ( isset( $_POST['is_public'] ) ) {
            check_ajax_referer( 'boa_public_nonce', $nonce_field );
        } else {
            check_ajax_referer( 'boa_ajax_nonce', $nonce_field );
        }

        $session_id = isset( $_POST['session_id'] ) ? absint( $_POST['session_id'] ) : 0;
        if ( $session_id === 0 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid session ID.', 'baba-online-academy' ) ) );
        }

        $action       = sanitize_text_field( $_POST['action_type'] ?? 'join' );
        $attendance_id= isset( $_POST['attendance_id'] ) ? absint( $_POST['attendance_id'] ) : 0;

        if ( 'leave' === $action && $attendance_id > 0 ) {
            $leave_time = sanitize_text_field( $_POST['leave_time'] ?? current_time( 'mysql' ) );
            $watch_time = isset( $_POST['watch_minutes'] ) ? absint( $_POST['watch_minutes'] ) : null;
            BOA_DB::complete_live_attendance( $attendance_id, $leave_time, $watch_time );
            wp_send_json_success( array( 'message' => __( 'Attendance updated.', 'baba-online-academy' ) ) );
        }

        $record = BOA_DB::record_live_attendance( array(
            'session_id'    => $session_id,
            'student_id'    => isset( $_POST['student_id'] ) ? absint( $_POST['student_id'] ) : null,
            'student_name'  => sanitize_text_field( $_POST['student_name'] ?? '' ),
            'student_email' => sanitize_email( $_POST['student_email'] ?? '' ),
            'join_time'     => sanitize_text_field( $_POST['join_time'] ?? current_time( 'mysql' ) ),
            'device_info'   => sanitize_text_field( $_POST['device_info'] ?? '' ),
            'ip_address'    => sanitize_text_field( $_POST['ip_address'] ?? '' ),
            'status'        => 'joined',
        ) );

        if ( is_wp_error( $record ) ) {
            wp_send_json_error( array( 'message' => $record->get_error_message() ) );
        }

        wp_send_json_success( array(
            'message'       => __( 'Attendance recorded.', 'baba-online-academy' ),
            'attendance_id' => $record,
        ) );
    }

    public static function get_public_live_sessions() {
        check_ajax_referer( 'boa_public_nonce', 'nonce' );

        $args = array(
            'page'     => 1,
            'per_page' => 50,
            'upcoming' => true,
            'status'   => 'scheduled',
        );

        $sessions = BOA_DB::get_live_sessions( $args );
        $items    = array();

        if ( ! empty( $sessions['items'] ) ) {
            foreach ( $sessions['items'] as $session ) {
                $items[] = array(
                    'session_id'    => (int) $session['session_id'],
                    'course_name'   => $session['course_name'],
                    'session_title' => $session['session_title'],
                    'start_time'    => $session['start_time'],
                    'end_time'      => $session['end_time'],
                    'platform'      => $session['platform'],
                    'join_url'      => $session['join_url'],
                    'status'        => $session['status'],
                    'instructor'    => $session['instructor_name'],
                );
            }
        }

        wp_send_json_success( array( 'items' => $items ) );
    }

    // ===== EXPORT/IMPORT SYSTEM =====
    
    /**
     * Export complete plugin data
     */
    public static function export_plugin_data() {
        check_ajax_referer( 'boa_reports_nonce', 'nonce' );
        
        try {
            $export_data = array();
            $export_data['export_info'] = array(
                'plugin_name' => 'Baba Online Academy',
                'version' => '1.2.3-enhanced',
                'export_date' => current_time( 'mysql' ),
                'export_by' => wp_get_current_user()->user_login ?? 'System'
            );
            
            // Export students
            $students_data = BOA_DB::get_students( array( 'per_page' => 9999 ) );
            $export_data['students'] = $students_data['items'] ?? array();
            
            // Export courses
            $courses_data = BOA_DB::get_courses( array( 'per_page' => 9999 ) );
            $export_data['courses'] = $courses_data['items'] ?? array();
            
            // Export fees
            $fees_data = BOA_DB::get_fees( array( 'per_page' => 9999, 'status' => '' ) );
            $export_data['fees'] = $fees_data['items'] ?? array();
            
            // Export form submissions
            global $wpdb;
            $submissions_table = $wpdb->prefix . 'boa_form_submissions';
            $form_submissions = $wpdb->get_results( "SELECT * FROM $submissions_table", ARRAY_A );
            $export_data['form_submissions'] = $form_submissions ?? array();
            
            // Export categories
            $categories_data = BOA_DB::get_categories( array( 'per_page' => 9999 ) );
            $export_data['categories'] = $categories_data['items'] ?? array();
            
            // Export settings
            $export_data['settings'] = array(
                'currency' => get_option( 'boa_currency', 'PKR' ),
                'institute_name' => get_option( 'boa_institute_name', '' ),
                'institute_address' => get_option( 'boa_institute_address', '' ),
                'institute_phone' => get_option( 'boa_institute_phone', '' ),
                'institute_email' => get_option( 'boa_institute_email', '' )
            );
            
            $json_data = json_encode( $export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
            
            // Generate filename
            $filename = 'boa-backup-' . date( 'Y-m-d-H-i-s' ) . '.json';
            
            // Send file for download
            header( 'Content-Type: application/json' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
            header( 'Content-Length: ' . strlen( $json_data ) );
            
            echo $json_data;
            exit;
            
        } catch ( Exception $e ) {
            wp_send_json_error( array( 'message' => 'Export failed: ' . $e->getMessage() ) );
        }
    }
    
    /**
     * Import plugin data (FIXED: Duplicate handling + Better error logging)
     */
    public static function import_plugin_data() {
        check_ajax_referer( 'boa_reports_nonce', 'nonce' );
        
        if ( empty( $_FILES['import_file'] ) ) {
            wp_send_json_error( array( 'message' => 'Please select a backup file.' ) );
        }
        
        $file = $_FILES['import_file'];
        
        // Validate file type
        if ( pathinfo( $file['name'], PATHINFO_EXTENSION ) !== 'json' ) {
            wp_send_json_error( array( 'message' => 'Only JSON backup files are supported.' ) );
        }
        
        // Read file content
        $json_content = file_get_contents( $file['tmp_name'] );
        $import_data = json_decode( $json_content, true );
        
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            wp_send_json_error( array( 'message' => 'Invalid backup file format. JSON Error: ' . json_last_error_msg() ) );
        }
        
        // Validate backup file structure
        if ( ! isset( $import_data['export_info'] ) || ! isset( $import_data['students'] ) ) {
            wp_send_json_error( array( 'message' => 'Invalid backup file structure.' ) );
        }
        
        global $wpdb;
        $results = array(
            'imported_students' => 0,
            'imported_courses' => 0,
            'imported_fees' => 0,
            'imported_categories' => 0,
            'imported_settings' => 0,
            'skipped_students' => 0,
            'skipped_courses' => 0,
            'skipped_fees' => 0,
            'errors' => array()
        );
        
        try {
            // Import categories first (dependencies)
            if ( isset( $import_data['categories'] ) && is_array( $import_data['categories'] ) ) {
                foreach ( $import_data['categories'] as $category ) {
                    $original_id = isset( $category['category_id'] ) ? $category['category_id'] : null;
                    unset( $category['category_id'] );
                    
                    // Check if category already exists by name
                    $existing = $wpdb->get_var( $wpdb->prepare(
                        "SELECT category_id FROM {$wpdb->prefix}boa_categories WHERE category_name = %s LIMIT 1",
                        $category['category_name']
                    ) );
                    
                    if ( ! $existing ) {
                        $result = $wpdb->insert( 
                            $wpdb->prefix . 'boa_categories', 
                            $category, 
                            array( '%s', '%s', '%s' )
                        );
                        if ( $result ) $results['imported_categories']++;
                    }
                }
            }
            
            // Create mapping for old course_id to new course_id
            $course_id_map = array();
            
            // Import courses
            if ( isset( $import_data['courses'] ) && is_array( $import_data['courses'] ) ) {
                foreach ( $import_data['courses'] as $course ) {
                    $original_course_id = isset( $course['course_id'] ) ? $course['course_id'] : null;
                    unset( $course['course_id'] );
                    
                    // Check if course already exists by name
                    $existing = $wpdb->get_var( $wpdb->prepare(
                        "SELECT course_id FROM {$wpdb->prefix}boa_courses WHERE course_name = %s LIMIT 1",
                        $course['course_name']
                    ) );
                    
                    if ( ! $existing ) {
                        $result = $wpdb->insert( 
                            $wpdb->prefix . 'boa_courses', 
                            $course, 
                            array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
                        );
                        if ( $result && $original_course_id ) {
                            $new_course_id = $wpdb->insert_id;
                            $course_id_map[ $original_course_id ] = $new_course_id;
                            $results['imported_courses']++;
                        }
                    } else {
                        $course_id_map[ $original_course_id ] = $existing;
                        $results['skipped_courses']++;
                    }
                }
            }
            
            // Create mapping for old student_id to new student_id
            $student_id_map = array();
            
            // Import students
            if ( isset( $import_data['students'] ) && is_array( $import_data['students'] ) ) {
                foreach ( $import_data['students'] as $student ) {
                    $original_student_id = isset( $student['student_id'] ) ? $student['student_id'] : null;
                    $student_uid = isset( $student['student_uid'] ) ? $student['student_uid'] : '';
                    
                    unset( $student['student_id'] );
                    
                    // Update course_id mapping if exists
                    if ( isset( $student['course_id'] ) && isset( $course_id_map[ $student['course_id'] ] ) ) {
                        $student['course_id'] = $course_id_map[ $student['course_id'] ];
                    }
                    
                    // Check if student already exists by UID or email
                    $existing = null;
                    if ( $student_uid ) {
                        $existing = $wpdb->get_var( $wpdb->prepare(
                            "SELECT student_id FROM {$wpdb->prefix}boa_students WHERE student_uid = %s LIMIT 1",
                            $student_uid
                        ) );
                    }
                    
                    if ( ! $existing && isset( $student['email'] ) ) {
                        $existing = $wpdb->get_var( $wpdb->prepare(
                            "SELECT student_id FROM {$wpdb->prefix}boa_students WHERE email = %s LIMIT 1",
                            $student['email']
                        ) );
                    }
                    
                    if ( ! $existing ) {
                        $result = $wpdb->insert( 
                            $wpdb->prefix . 'boa_students', 
                            $student, 
                            array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
                        );
                        
                        if ( $result && $original_student_id ) {
                            $new_student_id = $wpdb->insert_id;
                            $student_id_map[ $original_student_id ] = $new_student_id;
                            $results['imported_students']++;
                        } elseif ( ! $result ) {
                            $results['errors'][] = 'Student insert failed: ' . $wpdb->last_error;
                        }
                    } else {
                        $student_id_map[ $original_student_id ] = $existing;
                        $results['skipped_students']++;
                    }
                }
            }
            
            // Import fees
            if ( isset( $import_data['fees'] ) && is_array( $import_data['fees'] ) ) {
                foreach ( $import_data['fees'] as $fee ) {
                    $original_fee_id = isset( $fee['fee_id'] ) ? $fee['fee_id'] : null;
                    $invoice_id = isset( $fee['invoice_id'] ) ? $fee['invoice_id'] : '';
                    
                    unset( $fee['fee_id'] );
                    
                    // Update student_id and course_id mappings
                    if ( isset( $fee['student_id'] ) && isset( $student_id_map[ $fee['student_id'] ] ) ) {
                        $fee['student_id'] = $student_id_map[ $fee['student_id'] ];
                    } else {
                        $results['skipped_fees']++;
                        continue; // Skip if student not found
                    }
                    
                    if ( isset( $fee['course_id'] ) && isset( $course_id_map[ $fee['course_id'] ] ) ) {
                        $fee['course_id'] = $course_id_map[ $fee['course_id'] ];
                    }
                    
                    // Check if fee already exists by invoice_id
                    $existing = null;
                    if ( $invoice_id ) {
                        $existing = $wpdb->get_var( $wpdb->prepare(
                            "SELECT fee_id FROM {$wpdb->prefix}boa_fees WHERE invoice_id = %s LIMIT 1",
                            $invoice_id
                        ) );
                    }
                    
                    if ( ! $existing ) {
                        // Generate new unique invoice_id if duplicate
                        if ( $invoice_id ) {
                            $check_dup = $wpdb->get_var( $wpdb->prepare(
                                "SELECT fee_id FROM {$wpdb->prefix}boa_fees WHERE invoice_id = %s LIMIT 1",
                                $fee['invoice_id']
                            ) );
                            if ( $check_dup ) {
                                $fee['invoice_id'] = $fee['invoice_id'] . '-IMPORT-' . time();
                            }
                        }
                        
                        $result = $wpdb->insert( 
                            $wpdb->prefix . 'boa_fees', 
                            $fee, 
                            array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
                        );
                        
                        if ( $result ) {
                            $results['imported_fees']++;
                        } else {
                            $results['errors'][] = 'Fee insert failed: ' . $wpdb->last_error;
                        }
                    } else {
                        $results['skipped_fees']++;
                    }
                }
            }
            
            // Import form submissions (if present)
            if ( isset( $import_data['form_submissions'] ) && is_array( $import_data['form_submissions'] ) ) {
                $submissions_table = $wpdb->prefix . 'boa_form_submissions';
                foreach ( $import_data['form_submissions'] as $submission ) {
                    unset( $submission['submission_id'] );
                    
                    // Update student_id mapping
                    if ( isset( $submission['student_id'] ) && isset( $student_id_map[ $submission['student_id'] ] ) ) {
                        $submission['student_id'] = $student_id_map[ $submission['student_id'] ];
                        $wpdb->insert( $submissions_table, $submission );
                    }
                }
            }
            
            // Import settings
            if ( isset( $import_data['settings'] ) && is_array( $import_data['settings'] ) ) {
                foreach ( $import_data['settings'] as $key => $value ) {
                    update_option( 'boa_' . $key, $value );
                }
                $results['imported_settings'] = count( $import_data['settings'] );
            }
            
            // Build success message
            $message = 'Data imported successfully! ';
            $message .= "Students: {$results['imported_students']} imported";
            if ( $results['skipped_students'] > 0 ) {
                $message .= ", {$results['skipped_students']} skipped (duplicates)";
            }
            $message .= " | Courses: {$results['imported_courses']} imported";
            if ( $results['skipped_courses'] > 0 ) {
                $message .= ", {$results['skipped_courses']} skipped";
            }
            $message .= " | Fees: {$results['imported_fees']} imported";
            if ( $results['skipped_fees'] > 0 ) {
                $message .= ", {$results['skipped_fees']} skipped";
            }
            
            wp_send_json_success( array(
                'message' => $message,
                'results' => $results
            ) );
            
        } catch ( Exception $e ) {
            wp_send_json_error( array( 
                'message' => 'Import failed: ' . $e->getMessage(),
                'results' => $results
            ) );
        }
    }
    
    /**
     * Export specific data types to Excel
     */
    public static function export_to_excel() {
        check_ajax_referer( 'boa_reports_nonce', 'nonce' );
        
        $export_type = isset( $_POST['export_type'] ) ? sanitize_text_field( $_POST['export_type'] ) : '';
        $filters = isset( $_POST['filters'] ) ? (array) wp_unslash( $_POST['filters'] ) : array();
        
        try {
            switch ( $export_type ) {
                case 'students':
                    $data = BOA_DB::get_students( array_merge( $filters, array( 'per_page' => 9999 ) ) );
                    self::generate_csv_export( 'students', $data['items'] );
                    break;
                    
                case 'courses':
                    $data = BOA_DB::get_courses( array_merge( $filters, array( 'per_page' => 9999 ) ) );
                    self::generate_csv_export( 'courses', $data['items'] );
                    break;
                    
                case 'fees':
                    $data = BOA_DB::get_fees( array_merge( $filters, array( 'per_page' => 9999 ) ) );
                    self::generate_csv_export( 'fees', $data['items'] );
                    break;
                    
                case 'income':
                    $data = BOA_DB::get_report_income_details( $filters );
                    self::generate_csv_export( 'income-report', $data );
                    break;
                    
                default:
                    wp_send_json_error( array( 'message' => 'Invalid export type.' ) );
            }
            
        } catch ( Exception $e ) {
            wp_send_json_error( array( 'message' => 'Export failed: ' . $e->getMessage() ) );
        }
    }
    
    /**
     * Generate CSV export file
     */
    private static function generate_csv_export( $filename, $data ) {
        if ( empty( $data ) ) {
            wp_send_json_error( array( 'message' => 'No data to export.' ) );
        }
        
        // Set headers for CSV download
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '-' . date( 'Y-m-d' ) . '.csv"' );
        
        // Create CSV content
        $output = fopen( 'php://output', 'w' );
        
        // Add BOM for UTF-8
        fprintf( $output, chr(0xEF).chr(0xBB).chr(0xBF) );
        
        // Add headers
        if ( ! empty( $data ) ) {
            fputcsv( $output, array_keys( $data[0] ) );
        }
        
        // Add data rows
        foreach ( $data as $row ) {
            fputcsv( $output, $row );
        }
        
        fclose( $output );
        exit;
    }

    /**
     * Normalize $_FILES array for multiple uploads
     *
     * @param array $files
     * @return array
     */
    private static function normalize_files_array( $files ) {
        $normalized = array();

        if ( ! is_array( $files ) || ! isset( $files['name'] ) ) {
            return $normalized;
        }

        if ( is_array( $files['name'] ) ) {
            foreach ( $files['name'] as $index => $name ) {
                if ( empty( $name ) ) {
                    continue;
                }

                $normalized[] = array(
                    'name'     => $name,
                    'type'     => $files['type'][ $index ] ?? '',
                    'tmp_name' => $files['tmp_name'][ $index ] ?? '',
                    'error'    => $files['error'][ $index ] ?? 0,
                    'size'     => $files['size'][ $index ] ?? 0,
                );
            }
        } else {
            $normalized[] = $files;
        }

        return $normalized;
    }

    /**
     * Delete uploaded files when request fails
     *
     * @param array $files
     * @return void
     */
    private static function cleanup_uploaded_files( $files ) {
        if ( empty( $files ) ) {
            return;
        }

        foreach ( $files as $file ) {
            if ( ! empty( $file['path'] ) && file_exists( $file['path'] ) ) {
                wp_delete_file( $file['path'] );
            }
        }
    }
}

// ✅ Syntax verified block end
