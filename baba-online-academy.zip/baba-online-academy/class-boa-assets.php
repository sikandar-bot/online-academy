<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * BABA Online Academy - Asset Management
 *
 * (2025 BABA ARCHITECT - REFACTOR 3)
 * - Added new case 'boa-admission-reviews' for the admin review page.
 * - Added new function enqueue_public_assets() for the front-end shortcode.
 * - Added localization for public nonce (boa_public_data).
 */
class BOA_Assets {

    public static function init() {
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
        // (پبلک اثاثے صرف شارٹ کوڈ کے ذریعے لوڈ کیے جائیں گے)
    }

    public static function enqueue_admin_assets( $hook ) {
        // ہمارا مین مینو slug = baba-online-academy
        $page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';

        // صرف اپنے pages پر لوڈ کریں
        $allowed_pages = array(
            'baba-online-academy',
            'boa-dashboard',
            'boa-admission-reviews', // --- نیا پیج ---
            'boa-courses',
            'boa-students',
            'boa-fees',
            'boa-reports',
            'boa-settings',
            'boa-live-sessions',
        );

        if ( ! in_array( $page, $allowed_pages, true ) ) {
            return;
        }

        // Common CSS & JS
        wp_enqueue_style(
            'boa-common',
            BOA_PLUGIN_URL . 'boa-common.css',
            array(),
            BOA_VERSION
        );

        // Chart.js (CDN) – charts کیلئے
        wp_enqueue_script(
            'chartjs',
            'https://cdn.jsdelivr.net/npm/chart.js',
            array(),
            '4.4.0',
            true
        );

        wp_enqueue_script(
            'boa-common',
            BOA_PLUGIN_URL . 'boa-common.js',
            array( 'jquery' ),
            BOA_VERSION,
            true
        );

        // Page specific assets
        switch ( $page ) {
            // --- نیا: ایڈمیشن ریویو پیج ---
            case 'boa-admission-reviews':
                wp_enqueue_style(
                    'boa-admission-reviews',
                    BOA_PLUGIN_URL . 'page-admission-reviews/page-admission-reviews.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-admission-reviews',
                    BOA_PLUGIN_URL . 'page-admission-reviews/page-admission-reviews.js',
                    array( 'jquery', 'boa-common' ),
                    BOA_VERSION,
                    true
                );
                wp_localize_script(
                    'boa-admission-reviews',
                    'boa_admin_review_data',
                    array(
                        'ajax_url' => admin_url( 'admin-ajax.php' ),
                        'nonce'    => wp_create_nonce( 'boa_admin_review_nonce' ),
                        'currency' => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-live-sessions':
                wp_enqueue_style(
                    'boa-live-sessions',
                    BOA_PLUGIN_URL . 'page-live-sessions/page-live-sessions.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-live-sessions',
                    BOA_PLUGIN_URL . 'page-live-sessions/page-live-sessions.js',
                    array( 'jquery', 'boa-common' ),
                    BOA_VERSION,
                    true
                );
                wp_localize_script(
                    'boa-live-sessions',
                    'boa_live_sessions_data',
                    array(
                        'ajax_url' => admin_url( 'admin-ajax.php' ),
                        'nonce'    => wp_create_nonce( 'boa_ajax_nonce' ),
                        'courses'  => BOA_DB::get_courses( array( 'per_page' => 999 ) )['items'],
                        'i18n'     => array(
                            'loading'      => __( 'Loading…', 'baba-online-academy' ),
                            'noSessions'   => __( 'No sessions found.', 'baba-online-academy' ),
                            'required'     => __( 'Please fill all required fields.', 'baba-online-academy' ),
                            'newSession'   => __( 'Create Live Session', 'baba-online-academy' ),
                            'editSession'  => __( 'Edit Live Session', 'baba-online-academy' ),
                            'edit'         => __( 'Edit', 'baba-online-academy' ),
                            'attendance'   => __( 'Attendance', 'baba-online-academy' ),
                            'delete'       => __( 'Delete', 'baba-online-academy' ),
                            'noAttendance' => __( 'No attendance recorded yet.', 'baba-online-academy' ),
                            'confirmDelete'=> __( 'Do you really want to delete this session?', 'baba-online-academy' ),
                            'saving'       => __( 'Saving…', 'baba-online-academy' ),
                            'save'         => __( 'Save Session', 'baba-online-academy' ),
                            'allCourses'   => __( 'All Courses', 'baba-online-academy' ),
                            'noCourse'     => __( 'No Course', 'baba-online-academy' ),
                        ),
                    )
                );
                break;
            // --- /نیا ---

            case 'boa-students':
                wp_enqueue_style(
                    'boa-students',
                    BOA_PLUGIN_URL . 'page-students/page-students.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-students',
                    BOA_PLUGIN_URL . 'page-students/page-students.js',
                    array( 'jquery', 'chartjs', 'boa-common' ),
                    BOA_VERSION,
                    true
                );

                wp_localize_script(
                    'boa-students',
                    'boa_students_data',
                    array(
                        'ajax_url'               => admin_url( 'admin-ajax.php' ),
                        'nonce'                  => wp_create_nonce( 'boa_students_nonce' ),
                        'student_course_stats'   => BOA_DB::get_student_course_snapshot_stats(),
                        'recent_admissions'      => BOA_DB::get_student_recent_admissions(),
                        'courses_list'           => BOA_DB::get_courses(array('per_page' => 999))['items'],
                        'currency'               => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-fees':
                wp_enqueue_style(
                    'boa-fees',
                    BOA_PLUGIN_URL . 'page-fees/page-fees.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-fees',
                    BOA_PLUGIN_URL . 'page-fees/page-fees.js',
                    array( 'jquery', 'chartjs', 'boa-common' ),
                    BOA_VERSION,
                    true
                );

                wp_localize_script(
                    'boa-fees',
                    'boa_fees_data',
                    array(
                        'ajax_url'           => admin_url( 'admin-ajax.php' ),
                        'nonce'              => wp_create_nonce( 'boa_fees_nonce' ),
                        'fee_status_snapshot'=> BOA_DB::get_fee_status_snapshot(),
                        'today_collections'  => BOA_DB::get_today_collections(),
                        'upcoming_deadlines' => BOA_DB::get_fees_upcoming_deadlines_list(),
                        'courses_list'       => BOA_DB::get_courses(array('per_page' => 999))['items'],
                        'students_list'      => BOA_DB::get_students(array('per_page' => 999, 'status' => 'active'))['items'],
                        'currency'           => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-reports':
                wp_enqueue_style(
                    'boa-reports',
                    BOA_PLUGIN_URL . 'page-reports/page-reports.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-reports',
                    BOA_PLUGIN_URL . 'page-reports/page-reports.js',
                    array( 'jquery', 'chartjs', 'boa-common' ),
                    BOA_VERSION,
                    true
                );
                wp_localize_script(
                    'boa-reports',
                    'boa_reports_data',
                    array(
                        'ajax_url'     => admin_url( 'admin-ajax.php' ),
                        'nonce'        => wp_create_nonce( 'boa_reports_nonce' ),
                        'currency'     => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-settings':
                wp_enqueue_style(
                    'boa-settings',
                    BOA_PLUGIN_URL . 'page-settings/page-settings.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-settings',
                    BOA_PLUGIN_URL . 'page-settings/page-settings.js',
                    array( 'jquery', 'boa-common' ),
                    BOA_VERSION,
                    true
                );

                wp_localize_script(
                    'boa-settings',
                    'boa_settings_data',
                    array(
                        'ajax_url'        => admin_url( 'admin-ajax.php' ),
                        'nonce'           => wp_create_nonce( 'boa_settings_nonce' ),
                        'current_settings'=> BOA_DB::get_settings(),
                        'categories'      => BOA_DB::get_categories(),
                        'currency'        => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-courses':
                wp_enqueue_style(
                    'boa-courses',
                    BOA_PLUGIN_URL . 'page-courses/page-courses.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-courses',
                    BOA_PLUGIN_URL . 'page-courses/page-courses.js',
                    array( 'jquery', 'chartjs', 'boa-common' ),
                    BOA_VERSION,
                    true
                );
                
                wp_localize_script(
                    'boa-courses',
                    'boa_courses_data',
                    array(
                        'ajax_url'      => admin_url( 'admin-ajax.php' ),
                        'nonce'         => wp_create_nonce( 'boa_courses_nonce' ),
                        'categories'    => BOA_DB::get_categories(),
                        'courses_stats' => BOA_DB::get_course_stats(),
                        'category_stats' => BOA_DB::get_course_category_stats(),
                        'currency'      => boa_get_currency_symbol(),
                    )
                );
                break;

            case 'boa-dashboard':
            case 'baba-online-academy':
                wp_enqueue_style(
                    'boa-dashboard',
                    BOA_PLUGIN_URL . 'page-dashboard/page-dashboard.css',
                    array( 'boa-common' ),
                    BOA_VERSION
                );
                wp_enqueue_script(
                    'boa-dashboard',
                    BOA_PLUGIN_URL . 'page-dashboard/page-dashboard.js',
                    array( 'jquery', 'chartjs', 'boa-common' ),
                    BOA_VERSION,
                    true
                );

                wp_localize_script(
                    'boa-dashboard',
                    'boa_dashboard_data',
                    array(
                        'ajax_url'           => admin_url( 'admin-ajax.php' ),
                        'nonce'              => wp_create_nonce( 'boa_dashboard_nonce' ),
                        'upcoming_deadlines' => BOA_DB::get_dashboard_upcoming_deadlines(),
                        'income_data'        => BOA_DB::get_dashboard_monthly_income_data(),
                        'course_income'      => BOA_DB::get_dashboard_course_income_data(),
                        'recent_activity'    => BOA_DB::get_dashboard_recent_activity(),
                        'fee_status_overview'=> BOA_DB::get_dashboard_fee_status_overview(),
                        'currency'           => boa_get_currency_symbol(),
                    )
                );
                break;
        }
    }

    /**
     * نیا: پبلک اثاثے (Assets) لوڈ کرتا ہے۔
     * اسے baba-online-academy.php میں شارٹ کوڈ فنکشن سے کال کیا جاتا ہے۔
     */
    public static function enqueue_public_assets() {
        // یہ یقینی بناتا ہے کہ یہ صرف ایک بار لوڈ ہو
        if ( wp_style_is( 'boa-public-form', 'enqueued' ) ) {
            return;
        }

        wp_enqueue_style(
            'boa-public-form',
            BOA_PLUGIN_URL . 'page-admission-form/page-admission-form.css',
            array(),
            BOA_VERSION
        );

        wp_enqueue_script(
            'boa-public-form',
            BOA_PLUGIN_URL . 'page-admission-form/page-admission-form.js',
            array( 'jquery' ),
            BOA_VERSION,
            true
        );

        wp_localize_script(
            'boa-public-form',
            'boa_public_data',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'boa_public_nonce' ),
                'courses'  => BOA_DB::get_courses(array('per_page' => 999))['items'], // کورسز کی فہرست
                'currency' => boa_get_currency_symbol(),
                'status_page_url' => apply_filters( 'boa_application_status_url', '' ),
                'status_link_label' => __( 'Open status page', 'baba-online-academy' ),
                'status_note' => __( 'Keep this tracking code safe.', 'baba-online-academy' ),
            )
        );
    }

    public static function enqueue_public_live_sessions_assets() {
        if ( wp_style_is( 'boa-public-live-sessions', 'enqueued' ) ) {
            return;
        }

        wp_enqueue_style(
            'boa-public-live-sessions',
            BOA_PLUGIN_URL . 'page-live-sessions-public/page-live-sessions-public.css',
            array(),
            BOA_VERSION
        );

        wp_enqueue_script(
            'boa-public-live-sessions',
            BOA_PLUGIN_URL . 'page-live-sessions-public/page-live-sessions-public.js',
            array( 'jquery' ),
            BOA_VERSION,
            true
        );

        wp_localize_script(
            'boa-public-live-sessions',
            'boa_live_sessions_public',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'boa_public_nonce' ),
                'messages' => array(
                    'loading'     => __( 'Loading sessions…', 'baba-online-academy' ),
                    'noSessions'  => __( 'No upcoming sessions found.', 'baba-online-academy' ),
                    'join'        => __( 'Join Session', 'baba-online-academy' ),
                    'joined'      => __( 'Joining…', 'baba-online-academy' ),
                    'needDetails' => __( 'Please enter your name and email/phone before joining.', 'baba-online-academy' ),
                ),
            )
        );
    }
    public static function enqueue_status_assets() {
        if ( wp_style_is( 'boa-status-check', 'enqueued' ) ) {
            return;
        }

        wp_enqueue_style(
            'boa-status-check',
            BOA_PLUGIN_URL . 'page-application-status/page-application-status.css',
            array(),
            BOA_VERSION
        );

        wp_enqueue_script(
            'boa-status-check',
            BOA_PLUGIN_URL . 'page-application-status/page-application-status.js',
            array( 'jquery' ),
            BOA_VERSION,
            true
        );

        wp_localize_script(
            'boa-status-check',
            'boa_status_data',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'boa_public_nonce' ),
                'messages' => array(
                    'required'  => __( 'Please enter tracking code along with email or phone number.', 'baba-online-academy' ),
                    'not_found' => __( 'No application found for the provided details.', 'baba-online-academy' ),
                ),
            )
        );
    }



}

// ✅ Syntax verified block end

