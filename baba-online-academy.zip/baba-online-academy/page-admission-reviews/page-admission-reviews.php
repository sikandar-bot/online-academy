<?php
// 🟢 یہاں سے Admission Reviews PHP شروع ہو رہا ہے
if (!defined('ABSPATH')) exit;

/**
 * Admission Reviews پیج - BABA Online Academy
 * یہاں ایڈمن فرنٹ-اینڈ سے آنے والی درخواستوں کا جائزہ لے گا۔
 */
?>

<div id="boa-admin-reviews-root" class="boa-admin-wrap">
    <div class="boa-page-header">
        <div class="boa-header-left">
            <h1>Admission Reviews</h1>
            <p>Approve or reject new admission applications submitted from the public form</p>
        </div>
        <div class="boa-header-right">
            <div class="boa-toolbar-actions">
                <button type="button" class="boa-btn boa-btn-approve" id="boa-bulk-approve" onclick="BOA_BulkApproveAdmissions()" disabled>
                    <span class="dashicons dashicons-yes"></span>
                    Approve Selected
                </button>
                <button type="button" class="boa-btn boa-btn-reject" id="boa-bulk-reject" onclick="BOA_BulkRejectAdmissions()" disabled>
                    <span class="dashicons dashicons-no-alt"></span>
                    Reject Selected
                </button>
                <button type="button" class="boa-btn boa-btn-secondary" onclick="BOA_RefreshList()">
                    <span class="dashicons dashicons-update"></span>
                    Refresh List
                </button>
            </div>
        </div>
    </div>

    <div class="boa-card boa-table-card">
        <div class="boa-card-header">
            <h3>Pending Applications</h3>
            <p class="boa-text-muted">
                These applications require manual verification of the payment screenshot.
            </p>
        </div>
        <div class="boa-card-content">
            <table class="boa-data-table" id="boa-reviews-table">
                <thead>
                    <tr>
                        <th width="40">
                            <input type="checkbox" id="boa-review-select-all">
                        </th>
                        <th>Student Name</th>
                        <th>Email / Phone</th>
                        <th>Course</th>
                        <th>Amount Paid</th>
                        <th>Receipt</th>
                        <th>Submitted On</th>
                        <th width="180">Actions</th>
                    </tr>
                </thead>
                <tbody id="boa-reviews-tbody">
                    </tbody>
            </table>

            <div class="boa-pagination">
                <div class="boa-pagination-info">
                    Showing <span id="boa-showing-from">1</span>-<span id="boa-showing-to">10</span> 
                    of <span id="boa-total-records">0</span> pending applications
                </div>
                <div class="boa-pagination-controls">
                    <div class="boa-page-numbers" id="boa-page-numbers">
                        </div>
                </div>
            </div>
        </div>
    </div>

    <div class="boa-footer">
        <p>Baba Online Academy – Admission Review System</p>
    </div>
</div>

<div id="boa-receipt-viewer-modal" class="boa-modal">
    <div class="boa-modal-content boa-modal-large">
        <div class="boa-modal-header">
            <h3>Payment Receipt Viewer</h3>
            <button class="boa-close-btn" onclick="BOA_CloseReceiptModal()">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-modal-body">
            <div class="boa-receipt-viewer" id="boa-receipt-viewer">
                <p>Loading receipt...</p>
            </div>
            <div class="boa-receipt-thumbs" id="boa-receipt-thumb-list"></div>
        </div>
        <div class="boa-modal-footer">
            <button type="button" class="boa-btn boa-btn-secondary" onclick="BOA_CloseReceiptModal()">Close</button>
        </div>
    </div>
</div>

<template id="boa-review-row-template">
    <tr class="boa-review-row">
        <td class="boa-checkbox-cell">
            <input type="checkbox" class="boa-review-checkbox">
        </td>
        <td class="boa-student-name"></td>
        <td class="boa-student-contact"></td>
        <td class="boa-course-name"></td>
        <td class="boa-amount-paid"></td>
        <td>
            <button class="boa-btn boa-btn-sm boa-btn-outline boa-view-receipt-btn" onclick="BOA_ViewReceipt(this)">
                <span class="dashicons dashicons-media-document"></span>
                <span class="boa-receipt-btn-text">View Receipt</span>
            </button>
        </td>
        <td class="boa-submitted-date"></td>
        <td>
            <div class="boa-action-buttons">
                <button class="boa-btn boa-btn-sm boa-btn-approve" onclick="BOA_ApproveAdmission(this)" title="Approve">
                    <span class="dashicons dashicons-yes"></span>
                    Approve
                </button>
                <button class="boa-btn boa-btn-sm boa-btn-reject" onclick="BOA_RejectAdmission(this)" title="Reject">
                    <span class="dashicons dashicons-no"></span>
                    Reject
                </button>
            </div>
        </td>
    </tr>
</template>

// ✅ Syntax verified block end
