<?php
// 🟢 یہاں سے Reports PHP شروع ہو رہا ہے
if (!defined('ABSPATH')) exit;

/**
 * Reports پیج - BSSMS Computer Courses Management System
 * (نوٹ: اب یہ اصلی ڈیٹا بیس سے منسلک ہو رہا ہے)
 */

/**
 * Helper functions صرف اسی فائل کے لیے
 * (اب یہ BOA_DB کلاس کو استعمال کر رہے ہیں)
 */

if ( ! function_exists( 'boa_reports_get_courses' ) ) {
    function boa_reports_get_courses() {
        // 'per_page' کو 999 پر سیٹ کر کے تمام کورسز حاصل کریں
        $data = BOA_DB::get_courses(array('per_page' => 999));
        return $data['items'];
    }
}

if ( ! function_exists( 'boa_reports_get_categories' ) ) {
    function boa_reports_get_categories() {
        // یہ فنکشن اب براہِ راست BOA_DB سے کال ہو گا
        return BOA_DB::get_categories();
    }
}
?>

<div id="boa-reports-root">
    <div class="boa-page-header">
        <div class="boa-header-left">
            <h1>Reports</h1>
            <p>View income, student, fee, and course profitability reports</p>
        </div>
        <div class="boa-header-right">
            <div class="boa-toolbar-actions">
                <button class="boa-btn boa-btn-primary" onclick="BOA_ExportAllReports()">
                    <span class="dashicons dashicons-download"></span>
                    Export All
                </button>
                <button class="boa-btn boa-btn-secondary" id="boa-import-button" type="button">
                    <span class="dashicons dashicons-upload"></span>
                    Import
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_GenerateDemoData()">
                    <span class="dashicons dashicons-database"></span>
                    Demo Data
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_ExportExcel()">
                    <span class="dashicons dashicons-media-spreadsheet"></span>
                    Excel Download
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_PrintReports()">
                    <span class="dashicons dashicons-printer"></span>
                    Print
                </button>
            </div>
        </div>
    </div>

    <div class="boa-reports-tabs">
        <button class="boa-tab-btn boa-tab-active" data-tab="income">
            <span class="dashicons dashicons-money-alt"></span>
            Income Reports
        </button>
        <button class="boa-tab-btn" data-tab="students">
            <span class="dashicons dashicons-groups"></span>
            Student Reports
        </button>
        <button class="boa-tab-btn" data-tab="fees">
            <span class="dashicons dashicons-money"></span>
            Fee Reports
        </button>
        <button class="boa-tab-btn" data-tab="courses">
            <span class="dashicons dashicons-chart-line"></span>
            Course Profitability
        </button>
    </div>

    <div id="boa-tab-income" class="boa-tab-content boa-tab-active">
        <div class="boa-filter-card">
            <div class="boa-filter-header">
                <h3>Income Report Filters</h3>
            </div>
            <div class="boa-filter-content">
                <div class="boa-filter-row">
                    <div class="boa-form-group">
                        <label>Date Range</label>
                        <div class="boa-date-range">
                            <input type="date" id="boa-income-date-from" class="boa-form-input">
                            <span>to</span>
                            <input type="date" id="boa-income-date-to" class="boa-form-input">
                        </div>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-income-view-by">View By</label>
                        <select id="boa-income-view-by" class="boa-form-select">
                            <option value="monthly">Monthly</option>
                            <option value="yearly">Yearly</option>
                            <option value="course">Course-wise</option>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-income-course">Course</label>
                        <select id="boa-income-course" class="boa-form-select">
                            <option value="">All Courses</option>
                            <?php 
                            // اصلی ڈیٹا سے ڈراپ ڈاؤن بھریں
                            foreach ( boa_reports_get_courses() as $course ): ?>
                                <option value="<?php echo esc_attr( $course['course_id'] ); ?>">
                                    <?php echo esc_html( $course['course_name'] ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="boa-filter-actions">
                        <button class="boa-btn boa-btn-primary" onclick="BOA_ApplyIncomeFilters()">
                            Apply Filters
                        </button>
                        <button class="boa-btn boa-btn-outline" onclick="BOA_ResetIncomeFilters()">
                            Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="boa-charts-grid">
            <div class="boa-card boa-chart-card">
                <div class="boa-card-header">
                    <h3>Total Income Over Time</h3>
                </div>
                <div class="boa-card-content">
                    <canvas id="boa-income-trend-chart" width="400" height="300"></canvas>
                </div>
            </div>

            <div class="boa-card boa-chart-card">
                <div class="boa-card-header">
                    <h3>Course-wise Income</h3>
                </div>
                <div class="boa-card-content">
                    <canvas id="boa-course-income-chart" width="400" height="300"></canvas>
                </div>
            </div>
        </div>

        <div class="boa-card boa-table-card">
            <div class="boa-card-header">
                <h3>Income Details</h3>
                <div class="boa-table-tools">
                    <div class="boa-search-box">
                        <input type="text" id="boa-income-search" placeholder="Search income records..." class="boa-search-input">
                        <span class="dashicons dashicons-search"></span>
                    </div>
                    <select id="boa-income-status-filter" class="boa-filter-select">
                        <option value="">All Status</option>
                        <option value="paid">Paid</option>
                        <option value="pending">Pending</option>
                    </select>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_ExportIncomeExcel()">
                        Export Excel
                    </button>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_PrintIncomeTable()">
                        Print
                    </button>
                </div>
            </div>
            <div class="boa-card-content">
                <table class="boa-data-table" id="boa-income-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Amount</th>
                            <th>Month</th>
                            <th>Year</th>
                            <th>Payment Status</th>
                        </tr>
                    </thead>
                    <tbody id="boa-income-tbody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="boa-tab-students" class="boa-tab-content">
        <div class="boa-filter-card">
            <div class="boa-filter-header">
                <h3>Student Report Filters</h3>
            </div>
            <div class="boa-filter-content">
                <div class="boa-filter-row">
                    <div class="boa-form-group">
                        <label for="boa-student-course-filter">Course</label>
                        <select id="boa-student-course-filter" class="boa-form-select">
                            <option value="">All Courses</option>
                            <?php 
                            // اصلی ڈیٹا سے ڈراپ ڈاؤن بھریں
                            foreach ( boa_reports_get_courses() as $course ): ?>
                                <option value="<?php echo esc_attr( $course['course_id'] ); ?>">
                                    <?php echo esc_html( $course['course_name'] ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-student-status-filter">Status</label>
                        <select id="boa-student-status-filter" class="boa-form-select">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label>Admission Date</label>
                        <div class="boa-date-range">
                            <input type="date" id="boa-student-date-from" class="boa-form-input">
                            <span>to</span>
                            <input type="date" id="boa-student-date-to" class="boa-form-input">
                        </div>
                    </div>
                    <div class="boa-filter-actions">
                        <button class="boa-btn boa-btn-primary" onclick="BOA_ApplyStudentFilters()">
                            Apply Filters
                        </button>
                        <button class="boa-btn boa-btn-outline" onclick="BOA_ResetStudentFilters()">
                            Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="boa-cards-grid">
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Total Students</h3><span class="boa-card-icon dashicons dashicons-groups"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-total-students">0</div><div class="boa-stat-label">All time</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Active Students</h3><span class="boa-card-icon dashicons dashicons-yes"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-active-students">0</div><div class="boa-stat-label">Currently enrolled</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Completed Students</h3><span class="boa-card-icon dashicons dashicons-awards"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-completed-students">0</div><div class="boa-stat-label">Course completed</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>New This Month</h3><span class="boa-card-icon dashicons dashicons-plus-alt"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-new-students">0</div><div class="boa-stat-label">This month</div></div>
            </div>
        </div>

        <div class="boa-card boa-chart-card">
            <div class="boa-card-header"><h3>Students by Course</h3></div>
            <div class="boa-card-content"><canvas id="boa-students-course-chart" width="400" height="300"></canvas></div>
        </div>

        <div class="boa-card boa-table-card">
            <div class="boa-card-header">
                <h3>Student Report</h3>
                <div class="boa-table-tools">
                    <div class="boa-search-box"><input type="text" id="boa-student-search" placeholder="Search students..." class="boa-search-input"><span class="dashicons dashicons-search"></span></div>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_ExportStudentExcel()">Excel Download</button>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_PrintStudentTable()">Print</button>
                </div>
            </div>
            <div class="boa-card-content">
                <table class="boa-data-table" id="boa-student-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Admission Date</th>
                            <th>Status</th>
                            <th>Total Paid</th>
                            <th>Pending Amount</th>
                        </tr>
                    </thead>
                    <tbody id="boa-student-tbody">
                        </tbody>
                </table>
                <div class="boa-pagination">
                    <div class="boa-pagination-info">Showing <span id="boa-student-showing-from">0</span>-<span id="boa-student-showing-to">0</span> of <span id="boa-student-total-records">0</span> students</div>
                    <div class="boa-pagination-controls">
                        <select id="boa-student-rows-per-page" class="boa-rows-select"><option value="10">10 rows</option><option value="25">25 rows</option><option value="50">50 rows</option></select>
                        <div class="boa-page-numbers" id="boa-student-page-numbers"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="boa-tab-fees" class="boa-tab-content">
        <div class="boa-filter-card">
            <div class="boa-filter-header"><h3>Fee Report Filters</h3></div>
            <div class="boa-filter-content">
                <div class="boa-filter-row">
                    <div class="boa-form-group"><label>Date Range</label><div class="boa-date-range"><input type="date" id="boa-fee-date-from" class="boa-form-input"><span>to</span><input type="date" id="boa-fee-date-to" class="boa-form-input"></div></div>
                    <div class="boa-form-group">
                        <label for="boa-fee-status-filter">Status</label>
                        <select id="boa-fee-status-filter" class="boa-form-select">
                            <option value="">All Status</option><option value="paid">Paid</option><option value="pending">Pending</option><option value="overdue">Overdue</option>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-fee-course-filter">Course</label>
                        <select id="boa-fee-course-filter" class="boa-form-select">
                            <option value="">All Courses</option>
                            <?php foreach ( boa_reports_get_courses() as $course ): ?>
                                <option value="<?php echo esc_attr( $course['course_id'] ); ?>"><?php echo esc_html( $course['course_name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="boa-filter-actions">
                        <button class="boa-btn boa-btn-primary" onclick="BOA_ApplyFeeFilters()">Apply Filters</button>
                        <button class="boa-btn boa-btn-outline" onclick="BOA_ResetFeeFilters()">Reset</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="boa-cards-grid">
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Total Collected</h3><span class="boa-card-icon dashicons dashicons-money-alt"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-total-collected">0</div><div class="boa-stat-label">All time</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Total Pending</h3><span class="boa-card-icon dashicons dashicons-clock"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-total-pending">0</div><div class="boa-stat-label">Awaiting payment</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Overdue Amount</h3><span class="boa-card-icon dashicons dashicons-warning"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-overdue-amount">0</div><div class="boa-stat-label">Past due date</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Payments This Month</h3><span class="boa-card-icon dashicons dashicons-calendar"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-monthly-payments">0</div><div class="boa-stat-label">Current month</div></div>
            </div>
        </div>

        <div class="boa-charts-grid">
            <div class="boa-card boa-chart-card">
                <div class="boa-card-header"><h3>Fee Status Breakdown</h3></div>
                <div class="boa-card-content"><canvas id="boa-fee-status-chart" width="400" height="300"></canvas></div>
            </div>
            <div class="boa-card boa-chart-card">
                <div class="boa-card-header"><h3>Monthly Collections</h3></div>
                <div class="boa-card-content"><canvas id="boa-monthly-collections-chart" width="400" height="300"></canvas></div>
            </div>
        </div>

        <div class="boa-card boa-table-card">
            <div class="boa-card-header">
                <h3>Fee Report</h3>
                <div class="boa-table-tools">
                    <div class="boa-search-box"><input type="text" id="boa-fee-search" placeholder="Search fee records..." class="boa-search-input"><span class="dashicons dashicons-search"></span></div>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_ExportFeeExcel()">Export Excel</button>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_PrintFeeTable()">Print</button>
                </div>
            </div>
            <div class="boa-card-content">
                <table class="boa-data-table" id="boa-fee-table">
                    <thead>
                        <tr><th>Student</th><th>Course</th><th>Due Date</th><th>Payment Date</th><th>Amount</th><th>Status</th><th>Receipt</th></tr>
                    </thead>
                    <tbody id="boa-fee-tbody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="boa-tab-courses" class="boa-tab-content">
        <div class="boa-filter-card">
            <div class="boa-filter-header"><h3>Course Profitability Filters</h3></div>
            <div class="boa-filter-content">
                <div class="boa-filter-row">
                    <div class="boa-form-group"><label>Date Range</label><div class="boa-date-range"><input type="date" id="boa-course-date-from" class="boa-form-input"><span>to</span><input type="date" id="boa-course-date-to" class="boa-form-input"></div></div>
                    <div class="boa-form-group">
                        <label for="boa-course-category-filter">Category</label>
                        <select id="boa-course-category-filter" class="boa-form-select">
                            <option value="">All Categories</option>
                            <?php 
                            // اصلی ڈیٹا سے ڈراپ ڈاؤن بھریں
                            foreach ( boa_reports_get_categories() as $category ): ?>
                                <option value="<?php echo esc_attr( $category['category_id'] ); ?>"><?php echo esc_html( $category['category_name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-course-status-filter">Status</label>
                        <select id="boa-course-status-filter" class="boa-form-select">
                            <option value="">All Status</option><option value="active">Active</option><option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="boa-filter-actions">
                        <button class="boa-btn boa-btn-primary" onclick="BOA_ApplyCourseFilters()">Apply Filters</button>
                        <button class="boa-btn boa-btn-outline" onclick="BOA_ResetCourseFilters()">Reset</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="boa-cards-grid">
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Most Profitable Course</h3><span class="boa-card-icon dashicons dashicons-chart-bar"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-top-course">-</div><div class="boa-stat-label">Highest income</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Total Income</h3><span class="boa-card-icon dashicons dashicons-money-alt"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-total-course-income">0</div><div class="boa-stat-label">All courses</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Average Income</h3><span class="boa-card-icon dashicons dashicons-chart-area"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-avg-course-income">0</div><div class="boa-stat-label">Per course</div></div>
            </div>
            <div class="boa-card boa-stats-card">
                <div class="boa-card-header"><h3>Active Courses</h3><span class="boa-card-icon dashicons dashicons-book"></span></div>
                <div class="boa-card-content"><div class="boa-stat-number" id="boa-active-courses">0</div><div class="boa-stat-label">Currently running</div></div>
            </div>
        </div>

        <div class="boa-charts-grid">
            <div class="boa-card boa-chart-card">
                <div class="boa-card-header"><h3>Course Profitability</h3></div>
                <div class="boa-card-content"><canvas id="boa-course-profitability-chart" width="400" height="300"></canvas></div>
            </div>
            <div class="boa-card boa-chart-card">
                <div class="boa-card-header"><h3>Top 5 Courses by Income</h3></div>
                <div class="boa-card-content"><canvas id="boa-top-courses-chart" width="400" height="300"></canvas></div>
            </div>
        </div>

        <div class="boa-card boa-table-card">
            <div class="boa-card-header">
                <h3>Course Profitability Report</h3>
                <div class="boa-table-tools">
                    <div class="boa-search-box"><input type="text" id="boa-course-search" placeholder="Search courses..." class="boa-search-input"><span class="dashicons dashicons-search"></span></div>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_ExportCourseExcel()">Excel Download</button>
                    <button class="boa-btn boa-btn-outline" onclick="BOA_PrintCourseTable()">Print</button>
                </div>
            </div>
            <div class="boa-card-content">
                <table class="boa-data-table" id="boa-course-table">
                    <thead>
                        <tr><th>Course Name</th><th>Category</th><th>Total Students</th><th>Total Income</th><th>Average Fee</th><th>Profitability</th></tr>
                    </thead>
                    <tbody id="boa-course-tbody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="boa-footer">
        <p>BSSMS – Computer Courses Management System</p>
    </div>
</div>

<template id="boa-income-row-template">
    <tr class="boa-income-row">
        <td class="boa-payment-date"></td>
        <td class="boa-student-name"></td>
        <td class="boa-course-name"></td>
        <td class="boa-amount"></td>
        <td class="boa-month"></td>
        <td class="boa-year"></td>
        <td><span class="boa-status-badge"></span></td>
    </tr>
</template>

<template id="boa-student-row-template">
    <tr class="boa-student-row">
        <td class="boa-student-id"></td>
        <td class="boa-student-name"></td>
        <td class="boa-student-email"></td>
        <td class="boa-course-name"></td>
        <td class="boa-admission-date"></td>
        <td><span class="boa-status-badge"></span></td>
        <td class="boa-total-paid"></td>
        <td class="boa-pending-amount"></td>
    </tr>
</template>

<template id="boa-fee-row-template">
    <tr class="boa-fee-row">
        <td class="boa-student-name"></td>
        <td class="boa-course-name"></td>
        <td class="boa-due-date"></td>
        <td class="boa-payment-date"></td>
        <td class="boa-amount"></td>
        <td><span class="boa-status-badge"></span></td>
        <td class="boa-receipt-cell"></td>
    </tr>
</template>

<template id="boa-course-row-template">
    <tr class="boa-course-row">
        <td class="boa-course-name"></td>
        <td class="boa-category-name"></td>
        <td class="boa-total-students"></td>
        <td class="boa-total-income"></td>
        <td class="boa-avg-fee"></td>
        <td><span class="boa-profitability-badge"></span></td>
    </tr>
</template>

// ✅ Syntax verified block end
