// 🟢 یہاں سے Reports JavaScript شروع ہو رہا ہے
(function($) {
    'use strict';

    /**
     * BSSMS Reports - JavaScript functionality
     * (نوٹ: اب یہ فائل 'boa_reports_data' آبجیکٹ سے اصلی AJAX ڈیٹا استعمال کرتی ہے)
     */

    // اگر PHP سے boa_reports_data نہ آیا ہو تو سیف ڈیفالٹ بنا دو
    if (typeof window.boa_reports_data === 'undefined') {
        console.warn('boa_reports_data is not defined, using safe defaults.');
        window.boa_reports_data = {
            ajax_url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '',
            nonce: ''
        };
    }

    class BOA_Reports {
        constructor() {
            this.currentTab = 'income'; // ڈیفالٹ ٹیب
            this.studentPage = 1;
            this.studentPerPage = 10;
            this.studentTotalRecords = 0;
            this.currency = window.boa_reports_data?.currency || 'PKR'; // Currency symbol
            
            // چارٹ انسٹینسز کو محفوظ کریں
            this.chartInstances = {};
            
            this.init();
        }

        init() {
            this.loadCurrentTab(); // پہلی بار ڈیٹا لوڈ کریں
            this.bindEvents();
            console.log('BSSMS Reports initialized');
        }

        // === مرکزی ڈیٹا لوڈنگ فنکشن ===
        loadCurrentTab() {
            const self = this;
            const filters = this.getFiltersForTab(this.currentTab);
            
            $.ajax({
                url: window.boa_reports_data.ajax_url,
                type: 'POST',
                data: {
                    action: 'boa_get_report_data',
                    nonce: window.boa_reports_data.nonce,
                    tab: this.currentTab,
                    filters: filters
                },
                beforeSend: function() {
                    self.showLoading(self.currentTab);
                },
                success: function(response) {
                    if (response.success) {
                        self.renderReportData(self.currentTab, response.data);
                    } else {
                        self.showError('Failed to load report data.');
                    }
                },
                error: function() {
                    self.showError('Network error while loading reports.');
                },
                complete: function() {
                    self.hideLoading(self.currentTab);
                }
            });
        }
        
        // === فلٹرز حاصل کریں ===
        getFiltersForTab(tabName) {
            let filters = {};
            if (tabName === 'income') {
                filters.dateFrom = $('#boa-income-date-from').val();
                filters.dateTo = $('#boa-income-date-to').val();
                filters.course = $('#boa-income-course').val();
            } else if (tabName === 'students') {
                filters.dateFrom = $('#boa-student-date-from').val();
                filters.dateTo = $('#boa-student-date-to').val();
                filters.course = $('#boa-student-course-filter').val();
                filters.status = $('#boa-student-status-filter').val();
            } else if (tabName === 'fees') {
                filters.dateFrom = $('#boa-fee-date-from').val();
                filters.dateTo = $('#boa-fee-date-to').val();
                filters.course = $('#boa-fee-course-filter').val();
                filters.status = $('#boa-fee-status-filter').val();
            } else if (tabName === 'courses') {
                filters.dateFrom = $('#boa-course-date-from').val();
                filters.dateTo = $('#boa-course-date-to').val();
                filters.category = $('#boa-course-category-filter').val();
                filters.status = $('#boa-course-status-filter').val();
            }
            return filters;
        }

        // === ڈیٹا رینڈر کریں ===
        renderReportData(tabName, data) {
            switch(tabName) {
                case 'income':
                    this.renderIncomeReports(data);
                    break;
                case 'students':
                    this.renderStudentReports(data);
                    break;
                case 'fees':
                    this.renderFeeReports(data);
                    break;
                case 'courses':
                    this.renderCourseReports(data);
                    break;
            }
        }

        // === انکم رپورٹس ===
        renderIncomeReports(data) {
            this.initIncomeTrendChart(data.income_trend);
            this.initCourseIncomeChart(data.course_income_summary);
            this.loadIncomeTable(data.income_details);
            
            // (سٹیٹس کارڈز بعد میں شامل کر سکتے ہیں)
            // let totalIncome = data.income_details.reduce((sum, item) => sum + parseFloat(item.amount_paid), 0);
            // $('#boa-total-income').text(`$${totalIncome.toLocaleString()}`);
        }

        initIncomeTrendChart(chartData) {
            const ctx = document.getElementById('boa-income-trend-chart');
            if (!ctx) return;
            this.destroyChart('incomeTrend');
            
            const labels = chartData.labels.length > 0 ? chartData.labels : ['No Data'];
            const data = chartData.data.length > 0 ? chartData.data : [0];

            this.chartInstances.incomeTrend = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Monthly Income',
                        data: data,
                        borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 3, fill: true, tension: 0.4,
                    }]
                },
                options: this.getChartOptions(true, this.currency)
            });
        }

        initCourseIncomeChart(chartData) {
            const ctx = document.getElementById('boa-course-income-chart');
            if (!ctx) return;
            this.destroyChart('courseIncome');

            const labels = chartData.labels.length > 0 ? chartData.labels : ['No Data'];
            const data = chartData.data.length > 0 ? chartData.data : [0];

            this.chartInstances.courseIncome = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Course Income',
                        data: data,
                        backgroundColor: ['rgba(59, 130, 246, 0.8)', 'rgba(245, 158, 11, 0.8)', 'rgba(16, 185, 129, 0.8)', 'rgba(139, 92, 246, 0.8)', 'rgba(239, 68, 68, 0.8)'],
                        borderColor: ['#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', '#ef4444'],
                        borderWidth: 2
                    }]
                },
                options: this.getChartOptions(true, this.currency)
            });
        }

        loadIncomeTable(incomeData) {
            const tbody = $('#boa-income-tbody');
            const template = document.getElementById('boa-income-row-template');
            tbody.empty();

            if (!incomeData || incomeData.length === 0) {
                tbody.append('<tr><td colspan="7" class="boa-no-data">No income records found for these filters.</td></tr>');
                return;
            }

            incomeData.forEach(income => {
                const clone = template.content.cloneNode(true);
                const row = clone.querySelector('.boa-income-row');
                row.querySelector('.boa-payment-date').textContent = this.formatDate(income.payment_date);
                row.querySelector('.boa-student-name').textContent = income.student_name;
                row.querySelector('.boa-course-name').textContent = income.course_name;
                row.querySelector('.boa-amount').textContent = `${this.currency} ${parseFloat(income.amount_paid).toFixed(2)}`;
                row.querySelector('.boa-month').textContent = new Date(income.payment_date.replace(/-/g, '/')).toLocaleString('en-US', { month: 'short' });
                row.querySelector('.boa-year').textContent = new Date(income.payment_date.replace(/-/g, '/')).getFullYear();
                const statusBadge = row.querySelector('.boa-status-badge');
                statusBadge.textContent = this.getStatusText(income.status);
                statusBadge.className = `boa-status-badge ${this.getStatusClass(income.status)}`;
                tbody.append(row);
            });
        }

        // === سٹوڈنٹ رپورٹس ===
        renderStudentReports(data) {
            this.initStudentsCourseChart(data.students_by_course);
            this.loadStudentTable(data.student_list);
            this.updateStudentStats(data.student_stats);
        }

        initStudentsCourseChart(chartData) {
            const ctx = document.getElementById('boa-students-course-chart');
            if (!ctx) return;
            this.destroyChart('studentsCourse');

            const labels = chartData.map(item => item.course_name);
            const data = chartData.map(item => item.student_count);
            const finalLabels = data.length > 0 ? labels : ['No Data'];
            const finalData = data.length > 0 ? data : [1];
            const finalColors = data.length > 0 ? ['#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', '#ef4444'] : ['#e5e7eb'];

            this.chartInstances.studentsCourse = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: finalLabels,
                    datasets: [{
                        data: finalData,
                        backgroundColor: finalColors,
                        borderWidth: 2, borderColor: '#ffffff'
                    }]
                },
                options: this.getChartOptions(false)
            });
        }

        loadStudentTable(studentData) {
            const tbody = $('#boa-student-tbody');
            const template = document.getElementById('boa-student-row-template');
            tbody.empty();

            if (!studentData || !studentData.items || studentData.items.length === 0) {
                tbody.append('<tr><td colspan="8" class="boa-no-data">No students found for these filters.</td></tr>');
                this.updateStudentPagination(1, 0); // پیجینیشن ری سیٹ
                return;
            }

            studentData.items.forEach(student => {
                const clone = template.content.cloneNode(true);
                const row = clone.querySelector('.boa-student-row');
                row.querySelector('.boa-student-id').textContent = student.student_uid || `STU-${student.student_id}`;
                row.querySelector('.boa-student-name').textContent = student.name;
                row.querySelector('.boa-student-email').textContent = student.email;
                row.querySelector('.boa-course-name').textContent = student.course_name;
                row.querySelector('.boa-admission-date').textContent = this.formatDate(student.admission_date);
                row.querySelector('.boa-total-paid').textContent = `${this.currency} 0.00`; // (ToDo: Calculate)
                row.querySelector('.boa-pending-amount').textContent = `${this.currency} 0.00`; // (ToDo: Calculate)
                const statusBadge = row.querySelector('.boa-status-badge');
                statusBadge.textContent = this.getStatusText(student.status);
                statusBadge.className = `boa-status-badge ${this.getStatusClass(student.status)}`;
                tbody.append(row);
            });

            this.studentTotalRecords = studentData.total;
            this.updateStudentPagination(this.studentPage, studentData.total);
        }

        updateStudentPagination(currentPage, totalRecords) {
            const totalPages = Math.ceil(totalRecords / this.studentPerPage);
            const from = totalRecords > 0 ? ((currentPage - 1) * this.studentPerPage) + 1 : 0;
            const to = Math.min(currentPage * this.studentPerPage, totalRecords);
            
            $('#boa-student-showing-from').text(from);
            $('#boa-student-showing-to').text(to);
            $('#boa-student-total-records').text(totalRecords);
            
            const container = $('#boa-student-page-numbers');
            container.empty();
            if (!totalPages || totalPages < 2) return;
            // (پیجینیشن نمبرز کی لاجک یہاں...)
        }

        updateStudentStats(stats) {
            $('#boa-total-students').text(stats.total || 0);
            $('#boa-active-students').text(stats.active || 0);
            $('#boa-completed-students').text(stats.inactive || 0); // (inactive اور completed کو ایک مانا گیا ہے)
            $('#boa-new-students').text(stats.new_this_month || 0);
        }

        // === فیس رپورٹس ===
        renderFeeReports(data) {
            this.initFeeStatusChart(data.fee_status_snapshot);
            this.initMonthlyCollectionsChart(data.fee_stats); // (ToDo: اس کے لیے الگ DB فنکشن چاہیے)
            this.loadFeeTable(data.fee_list);
            this.updateFeeStats(data.fee_stats);
        }

        initFeeStatusChart(chartData) {
            const ctx = document.getElementById('boa-fee-status-chart');
            if (!ctx) return;
            this.destroyChart('feeStatus');
            
            let labels = chartData.map(item => item.status.charAt(0).toUpperCase() + item.status.slice(1));
            let data = chartData.map(item => item.count);
            let colors = labels.map(label => {
                if (label === 'Paid') return '#10b981';
                if (label === 'Pending') return '#f59e0b';
                if (label === 'Overdue') return '#ef4444';
                return '#e5e7eb';
            });

            if (data.length === 0) { labels = ['No Data']; data = [1]; colors = ['#e5e7eb']; }

            this.chartInstances.feeStatus = new Chart(ctx, {
                type: 'doughnut',
                data: { labels: labels, datasets: [{ data: data, backgroundColor: colors, borderWidth: 2, borderColor: '#ffffff' }] },
                options: this.getChartOptions(false)
            });
        }

        initMonthlyCollectionsChart(chartData) {
            // (ToDo: یہ چارٹ اصل میں 'income_trend' کا ڈیٹا استعمال کر سکتا ہے)
            const ctx = document.getElementById('boa-monthly-collections-chart');
            if (!ctx) return;
            this.destroyChart('monthlyCollections');
            this.chartInstances.monthlyCollections = new Chart(ctx, {
                type: 'bar',
                data: { labels: ['No Data'], datasets: [{ label: 'Monthly Collections', data: [0], backgroundColor: 'rgba(59, 130, 246, 0.8)' }] },
                options: this.getChartOptions(true, this.currency)
            });
        }

        loadFeeTable(feeData) {
            const tbody = $('#boa-fee-tbody');
            const template = document.getElementById('boa-fee-row-template');
            tbody.empty();

            if (!feeData || !feeData.items || feeData.items.length === 0) {
                tbody.append('<tr><td colspan="7" class="boa-no-data">No fee records found for these filters.</td></tr>');
                return;
            }

            feeData.items.forEach(fee => {
                const clone = template.content.cloneNode(true);
                const row = clone.querySelector('.boa-fee-row');
                row.querySelector('.boa-student-name').textContent = fee.student_name;
                row.querySelector('.boa-course-name').textContent = fee.course_name;
                row.querySelector('.boa-due-date').textContent = this.formatDate(fee.due_date);
                row.querySelector('.boa-payment-date').textContent = this.formatDate(fee.payment_date);
                row.querySelector('.boa-amount').textContent = `${this.currency} ${parseFloat(fee.amount_paid || fee.amount_due).toFixed(2)}`;
                const statusBadge = row.querySelector('.boa-status-badge');
                statusBadge.textContent = this.getStatusText(fee.status);
                statusBadge.className = `boa-status-badge ${this.getStatusClass(fee.status)}`;
                row.querySelector('.boa-receipt-cell').innerHTML = fee.receipt_url ? '<span class="dashicons dashicons-media-document"></span>' : '-';
                tbody.append(row);
            });
        }

        updateFeeStats(stats) {
            $('#boa-total-collected').text(`${this.currency} ${parseFloat(stats.total_collected || 0).toLocaleString()}`);
            $('#boa-total-pending').text(`${this.currency} ${parseFloat(stats.pending_amount || 0).toLocaleString()}`);
            $('#boa-overdue-amount').text(`${this.currency} ${parseFloat(stats.overdue_fees || 0).toLocaleString()}`); // (یہ رقم ہونی چاہیے، گنتی نہیں)
            $('#boa-monthly-payments').text(`${this.currency} ${parseFloat(stats.total_collected || 0).toLocaleString()}`); // (یہ صرف اس مہینے کا ہونا چاہیے)
        }

        // === کورس پرافٹابیلیٹی رپورٹس ===
        renderCourseReports(data) {
            this.initCourseProfitabilityChart(data.course_profitability);
            this.initTopCoursesChart(data.top_courses);
            this.loadCourseTable(data.course_list);
            // (سٹیٹس کارڈز بعد میں شامل کر سکتے ہیں)
        }

        initCourseProfitabilityChart(chartData) {
            const ctx = document.getElementById('boa-course-profitability-chart');
            if (!ctx) return;
            this.destroyChart('courseProfit');

            const labels = chartData.labels.length > 0 ? chartData.labels : ['No Data'];
            const data = chartData.data.length > 0 ? chartData.data : [0];

            this.chartInstances.courseProfit = new Chart(ctx, {
                type: 'bar',
                data: { labels: labels, datasets: [{ label: 'Course Income', data: data, backgroundColor: 'rgba(59, 130, 246, 0.8)' }] },
                options: this.getChartOptions(true, this.currency)
            });
        }

        initTopCoursesChart(chartData) {
            const ctx = document.getElementById('boa-top-courses-chart');
            if (!ctx) return;
            this.destroyChart('topCourses');

            const labels = chartData.labels.length > 0 ? chartData.labels : ['No Data'];
            const data = chartData.data.length > 0 ? chartData.data : [0];
            
            this.chartInstances.topCourses = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Income',
                        data: data,
                        backgroundColor: ['rgba(59, 130, 246, 0.8)', 'rgba(245, 158, 11, 0.8)', 'rgba(16, 185, 129, 0.8)', 'rgba(139, 92, 246, 0.8)', 'rgba(239, 68, 68, 0.8)'],
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: { x: { beginAtZero: true, ticks: { callback: (value) => '$' + value.toLocaleString() } } }
                }
            });
        }

        loadCourseTable(courseData) {
            const tbody = $('#boa-course-tbody');
            const template = document.getElementById('boa-course-row-template');
            tbody.empty();
            tbody.append('<tr><td colspan="6" class="boa-no-data">This report tab is not yet complete.</td></tr>');
            // (ToDo: اس ٹیبل کے لیے DB فنکشنز مکمل کرنے ہیں)
        }

        // === ایونٹ بائنڈنگ ===
        bindEvents() {
            // ٹیب سوئچنگ
            $('.boa-reports-tabs .boa-tab-btn').on('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
            
            // فلٹر بٹنز
            $('button[onclick="BOA_ApplyIncomeFilters()"]').on('click', () => this.loadCurrentTab());
            $('button[onclick="BOA_ApplyStudentFilters()"]').on('click', () => this.loadCurrentTab());
            $('button[onclick="BOA_ApplyFeeFilters()"]').on('click', () => this.loadCurrentTab());
            $('button[onclick="BOA_ApplyCourseFilters()"]').on('click', () => this.loadCurrentTab());
            
            // ری سیٹ بٹنز
            $('button[onclick="BOA_ResetIncomeFilters()"]').on('click', () => this.resetFilters('income'));
            $('button[onclick="BOA_ResetStudentFilters()"]').on('click', () => this.resetFilters('students'));
            $('button[onclick="BOA_ResetFeeFilters()"]').on('click', () => this.resetFilters('fees'));
            $('button[onclick="BOA_ResetCourseFilters()"]').on('click', () => this.resetFilters('courses'));

            // Import modal trigger fallback (in case inline onclick is stripped)
            $(document).on('click', '#boa-import-button', (event) => {
                event.preventDefault();
                if (typeof window.BOA_OpenImportModal === 'function') {
                    window.BOA_OpenImportModal();
                } else {
                    this.showError('Import handler not available.');
                }
            });
        }

        // === ٹیب سوئچ ===
        switchTab(tabName) {
            $('.boa-tab-content').removeClass('boa-tab-active');
            $('.boa-reports-tabs .boa-tab-btn').removeClass('boa-tab-active');
            $(`#boa-tab-${tabName}`).addClass('boa-tab-active');
            $(`.boa-reports-tabs .boa-tab-btn[data-tab="${tabName}"]`).addClass('boa-tab-active');
            this.currentTab = tabName;
            this.loadCurrentTab();
        }
        
        resetFilters(tabName) {
            $(`#boa-tab-${tabName} .boa-filter-row`).find('input[type="date"], select').val('');
            this.loadCurrentTab();
        }

        // === یوٹیلیٹی فنکشنز ===
        showLoading(tabName) { $(`#boa-tab-${tabName}`).css('opacity', 0.5); }
        hideLoading(tabName) { $(`#boa-tab-${tabName}`).css('opacity', 1); }
        destroyChart(chartId) { if (this.chartInstances[chartId]) { this.chartInstances[chartId].destroy(); } }
        
        getChartOptions(legendDisplay = false, tooltipPrefix = '') {
            return {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: legendDisplay },
                    tooltip: {
                        callbacks: {
                            label: (context) => `${context.dataset.label}: ${tooltipPrefix}${context.parsed.y.toLocaleString()}`
                        }
                    }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: (value) => `${tooltipPrefix}${value.toLocaleString()}` } }
                }
            };
        }

        formatDate(dateString) { if (!dateString || dateString === '0000-00-00') return 'N/A'; const date = new Date(dateString.replace(/-/g, '/')); return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }); }
        getStatusText(status) { const map = { 'paid': 'Paid', 'pending': 'Pending', 'overdue': 'Overdue', 'active': 'Active', 'inactive': 'Inactive' }; return map[status] || 'Unknown'; }
        getStatusClass(status) { const map = { 'paid': 'boa-status-paid', 'pending': 'boa-status-pending', 'overdue': 'boa-status-overdue', 'active': 'boa-status-paid', 'inactive': 'boa-status-overdue' }; return map[status] || 'boa-status-unknown'; }
        showError(message) { console.error('BSSMS Error:', message); alert(`Error: ${message}`); }
        showSuccess(message) { console.log('BSSMS Success:', message); alert(`Success: ${message}`); }
        
        // Get current filters from all tabs
        getCurrentFilters() {
            const filters = {};
            
            // Date filters
            const dateFrom = $('#boa-date-from').val();
            const dateTo = $('#boa-date-to').val();
            
            if (dateFrom) filters.dateFrom = dateFrom;
            if (dateTo) filters.dateTo = dateTo;
            
            // Course filter (available in fees section)
            const courseFilter = $('#boa-course-filter').val();
            if (courseFilter) filters.course = courseFilter;
            
            // Status filter (available in students section)
            const statusFilter = $('#boa-status-filter').val();
            if (statusFilter) filters.status = statusFilter;
            
            return filters;
        }
    }

    // === گلوبل فنکشنز (اب صرف پلیس ہولڈر ہیں) ===
    window.boaReports = new BOA_Reports();
    window.BOA_ApplyIncomeFilters = () => {};
    window.BOA_ResetIncomeFilters = () => {};
    window.BOA_ApplyStudentFilters = () => {};
    window.BOA_ResetStudentFilters = () => {};
    window.BOA_ApplyFeeFilters = () => {};
    window.BOA_ResetFeeFilters = () => {};
    window.BOA_ApplyCourseFilters = () => {};
    window.BOA_ResetCourseFilters = () => {};

    // ایکسپورٹ اینڈ پرنٹ فنکشنز
    window.BOA_ExportAllReports = function() {
        boaReports.showSuccess('Complete data export started. Please wait...');
        
        // Create form for file download
        const form = $('<form>', {
            method: 'POST',
            action: window.boa_reports_data.ajax_url,
            style: 'display: none;'
        });
        
        // Add form fields
        form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'boa_export_plugin_data'
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: window.boa_reports_data.nonce
        }));
        
        // Submit form
        $('body').append(form);
        form.submit();
        form.remove();
        
        // Hide success message after a moment
        setTimeout(() => {
            if ($('.alert-success').length) {
                $('.alert-success').fadeOut();
            }
        }, 3000);
    };

    window.BOA_ExportIncomeExcel = function() {
        const filters = boaReports.getCurrentFilters();
        boaReports.exportToExcel('income', filters);
    };

    window.BOA_PrintIncomeTable = () => { window.print(); };

    window.BOA_ExportStudentExcel = function() {
        boaReports.exportToExcel('students', boaReports.getCurrentFilters());
    };

    window.BOA_PrintStudentTable = () => { window.print(); };

    window.BOA_ExportFeeExcel = function() {
        boaReports.exportToExcel('fees', boaReports.getCurrentFilters());
    };

    window.BOA_PrintFeeTable = () => { window.print(); };

    window.BOA_ExportCourseExcel = function() {
        boaReports.exportToExcel('courses', boaReports.getCurrentFilters());
    };

    window.BOA_PrintCourseTable = () => { window.print(); };

    window.BOA_ExportExcel = function() {
        const currentTab = $('#boa-report-tabs .boa-tab-active').data('tab');
        boaReports.exportToExcel(currentTab, boaReports.getCurrentFilters());
    };

    window.BOA_PrintReports = () => { window.print(); };

    window.BOA_OpenImportModal = function() {
        // Create import modal
        const modalHtml = `
            <div id="boa-import-modal" class="boa-modal boa-modal-open">
                <div class="boa-modal-content">
                    <div class="boa-modal-header">
                        <h3>Import Plugin Data</h3>
                        <button class="boa-close-btn" onclick="BOA_CloseImportModal()">
                            <span class="dashicons dashicons-no"></span>
                        </button>
                    </div>
                    <div class="boa-modal-body">
                        <form id="boa-import-form" onsubmit="return BOA_SubmitImport(event)">
                            <div class="boa-form-group">
                                <label for="boa-import-file">Select Backup File (.json)</label>
                                <input type="file" id="boa-import-file" name="import_file" accept=".json" required class="boa-form-input">
                                <small>Only JSON backup files exported by this plugin are supported.</small>
                            </div>
                            <div class="boa-form-group">
                                <label>
                                    <input type="checkbox" id="boa-import-confirm" required>
                                    I confirm that I want to import this data. This action cannot be undone.
                                </label>
                            </div>
                            <div class="boa-import-progress" id="boa-import-progress" style="display: none;">
                                <div class="boa-progress-bar">
                                    <div class="boa-progress-fill" id="boa-progress-fill"></div>
                                </div>
                                <div class="boa-progress-text" id="boa-progress-text">Importing...</div>
                            </div>
                        </form>
                    </div>
                    <div class="boa-modal-footer">
                        <button type="button" class="boa-btn boa-btn-secondary" onclick="BOA_CloseImportModal()">Cancel</button>
                        <button type="submit" form="boa-import-form" class="boa-btn boa-btn-primary">Import Data</button>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHtml);
    };

    window.BOA_CloseImportModal = function() {
        $('#boa-import-modal').remove();
    };

    window.BOA_SubmitImport = function(event) {
        event.preventDefault();
        
        const fileInput = $('#boa-import-file')[0];
        const confirmCheck = $('#boa-import-confirm');
        
        if (!fileInput.files.length) {
            boaReports.showError('Please select a backup file.');
            return false;
        }
        
        if (!confirmCheck.prop('checked')) {
            boaReports.showError('Please confirm that you want to import this data.');
            return false;
        }
        
        // Show progress
        $('#boa-import-progress').show();
        $('#boa-progress-text').text('Importing data...');
        $('#boa-progress-fill').css('width', '10%');
        
        // Prepare form data
        const formData = new FormData();
        formData.append('action', 'boa_import_plugin_data');
        formData.append('nonce', window.boa_reports_data.nonce);
        formData.append('import_file', fileInput.files[0]);
        
        // Submit import
        $.ajax({
            url: window.boa_reports_data.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = (e.loaded / e.total) * 100;
                        $('#boa-progress-fill').css('width', percentComplete + '%');
                    }
                });
                return xhr;
            },
            success: function(response) {
                $('#boa-progress-fill').css('width', '100%');
                $('#boa-progress-text').text('Import completed!');
                
                setTimeout(() => {
                    if (response.success) {
                        BOA_CloseImportModal();
                        boaReports.showSuccess('Data imported successfully! ' + 
                            'Students: ' + response.data.results.imported_students + ', ' +
                            'Courses: ' + response.data.results.imported_courses + ', ' +
                            'Fees: ' + response.data.results.imported_fees);
                        
                        // Reload page to show imported data
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        BOA_CloseImportModal();
                        boaReports.showError('Import failed: ' + response.data.message);
                    }
                }, 1000);
            },
            error: function() {
                BOA_CloseImportModal();
                boaReports.showError('Network error during import.');
            }
        });
        
        return false;
    };

    window.BOA_GenerateDemoData = function() {
        boaReports.showSuccess('Demo data functionality will be implemented');
    };

    // Add exportToExcel method to boaReports class
    boaReports.exportToExcel = function(type, filters) {
        const form = $('<form>', {
            method: 'POST',
            action: window.boa_reports_data.ajax_url,
            style: 'display: none;'
        });
        
        // Add form fields
        form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'boa_export_to_excel'
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: window.boa_reports_data.nonce
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'export_type',
            value: type
        }));
        
        // Add filters
        Object.keys(filters).forEach(key => {
            if (filters[key]) {
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'filters[' + key + ']',
                    value: filters[key]
                }));
            }
        });
        
        // Submit form
        $('body').append(form);
        form.submit();
        form.remove();
        
        boaReports.showSuccess('Export started. Your download will begin shortly.');
        
        setTimeout(() => {
            if ($('.alert-success').length) {
                $('.alert-success').fadeOut();
            }
        }, 3000);
    };

    // === ڈاکیومینٹ ریڈی ===
    $(document).ready(function() {
        console.log('BSSMS Reports ready');
    });

})(jQuery);
// ✅ Syntax verified block end
