<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BOA_Activator {

    public static function activate() {
        // مرحلہ 1: ڈیٹا بیس یا آپشنز initialise کریں
        // یہ ہمارے نئے فنکشن کو کال کرے گا جو class-boa-db.php میں ہے۔
        BOA_DB::maybe_create_tables();

        // مرحلہ 2: ڈیفالٹ سیٹنگز (یہ wp_options میں ہی رہیں گی)
        $defaults = array(
            'system_name'    => 'Baba Online Academy',
            'admin_email'    => get_option( 'admin_email' ),
            'default_language' => 'en_US',
            'timezone'       => 'Asia/Karachi',
            'date_format'    => 'Y-m-d',
            'currency'       => 'PKR',
            'primary_color'  => '#3b82f6',
            'accent_color'   => '#f59e0b',
            'theme_mode'     => 'light',
            'login_title'    => 'Welcome to Baba Online Academy',
            'footer_text'    => 'Powered by Baba Online Academy'
        );

        $current = get_option( 'boa_settings', array() );
        update_option( 'boa_settings', wp_parse_args( $current, $defaults ) );

        // مرحلہ 3: ڈیفالٹ کیٹیگریز شامل کریں (اگر موجود نہ ہوں)
        self::create_default_categories();

        // مرحلہ 4: Manual table creation کی verification
        self::force_recreate_tables();

        // (نوٹ: پرانی 'boa_categories' آپشن والی لائن ہٹا دی گئی ہے
        // کیونکہ اب وہ کسٹم ٹیبل میں ہیں)
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled( 'boa_auto_complete_sessions' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'boa_auto_complete_sessions' );
        }
    }

    private static function create_default_categories() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'boa_categories';
        
        // چیک کریں کہ کیا کوئی categories موجود ہیں
        $existing_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        
        if ($existing_count == 0) {
            // ڈیفالٹ categories شامل کریں
            $default_categories = array(
                'Web Development',
                'Mobile App Development', 
                'Data Science',
                'Digital Marketing',
                'Graphic Design',
                'Computer Hardware',
                'Networking',
                'Database Management'
            );
            
            foreach ($default_categories as $category) {
                $wpdb->insert(
                    $table_name,
                    array(
                        'category_name' => $category,
                        'status' => 'active'
                    ),
                    array('%s', '%s')
                );
            }
        }
    }

    private static function force_recreate_tables() {
        global $wpdb;
        
        error_log('BOA Activator - Starting forced table recreation');
        
        $categories_table = $wpdb->prefix . 'boa_categories';
        $courses_table = $wpdb->prefix . 'boa_courses';
        $students_table = $wpdb->prefix . 'boa_students';
        $fees_table = $wpdb->prefix . 'boa_fees';
        
        // Drop existing tables if they exist (to fix structure issues)
        error_log('BOA Activator - Dropping existing tables if they exist');
        
        // Drop fees table first (due to foreign keys)
        $wpdb->query("DROP TABLE IF EXISTS $fees_table");
        error_log('BOA Activator - Dropped fees table');
        
        // Drop students table
        $wpdb->query("DROP TABLE IF EXISTS $students_table");
        error_log('BOA Activator - Dropped students table');
        
        // Drop courses table
        $wpdb->query("DROP TABLE IF EXISTS $courses_table");
        error_log('BOA Activator - Dropped courses table');
        
        // Drop categories table
        $wpdb->query("DROP TABLE IF EXISTS $categories_table");
        error_log('BOA Activator - Dropped categories table');
        
        // Create categories table
        error_log('BOA Activator - Creating categories table manually');
        $sql = "CREATE TABLE $categories_table (
            category_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            category_name VARCHAR(255) NOT NULL, 
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            PRIMARY KEY (category_id)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Categories table creation result: ' . ($result !== false ? 'Success' : 'Failed'));
        
        // Create courses table
        error_log('BOA Activator - Creating courses table manually');
        $sql = "CREATE TABLE $courses_table (
            course_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            course_name VARCHAR(255) NOT NULL, 
            category_id BIGINT(20) UNSIGNED NOT NULL,
            duration VARCHAR(100) DEFAULT NULL, 
            fee_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            start_date DATE DEFAULT NULL, 
            end_date DATE DEFAULT NULL,
            description TEXT DEFAULT NULL, 
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (course_id), 
            KEY category_id (category_id)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Courses table creation result: ' . ($result !== false ? 'Success' : 'Failed'));
        
        // Create students table
        error_log('BOA Activator - Creating students table manually');
        $sql = "CREATE TABLE $students_table (
            student_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            student_uid VARCHAR(100) NOT NULL, 
            name VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL, 
            phone VARCHAR(50) DEFAULT NULL,
            course_id BIGINT(20) UNSIGNED NOT NULL, 
            admission_date DATE DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active', 
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (student_id), 
            UNIQUE KEY student_uid (student_uid),
            KEY course_id (course_id), 
            KEY email (email)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Students table creation result: ' . ($result !== false ? 'Success' : 'Failed'));
        
        // Create fees table
        error_log('BOA Activator - Creating fees table manually');
        $sql = "CREATE TABLE $fees_table (
            fee_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id BIGINT(20) UNSIGNED NOT NULL, 
            course_id BIGINT(20) UNSIGNED NOT NULL,
            invoice_id VARCHAR(100) DEFAULT NULL, 
            amount_due DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            amount_paid DECIMAL(10, 2) NOT NULL DEFAULT 0.00, 
            due_date DATE DEFAULT NULL,
            payment_date DATE DEFAULT NULL, 
            status VARCHAR(20) NOT NULL DEFAULT 'pending', 
            receipt_url VARCHAR(1000) DEFAULT NULL, 
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (fee_id), 
            KEY student_id (student_id), 
            KEY course_id (course_id)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Fees table creation result: ' . ($result !== false ? 'Success' : 'Failed'));
        
        // Create form submissions table (NEW)
        $submissions_table = $wpdb->prefix . 'boa_form_submissions';
        error_log('BOA Activator - Creating form submissions table manually');
        $sql = "CREATE TABLE $submissions_table (
            submission_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id BIGINT(20) UNSIGNED DEFAULT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(50) DEFAULT NULL,
            course_id BIGINT(20) UNSIGNED NOT NULL,
            student_name VARCHAR(255) NOT NULL,
            tracking_token VARCHAR(64) NOT NULL,
            submission_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) NOT NULL DEFAULT 'pending_review',
            status_updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status_notes TEXT DEFAULT NULL,
            receipt_file_hash VARCHAR(64) DEFAULT NULL,
            receipt_original_name VARCHAR(255) DEFAULT NULL,
            discount_amount DECIMAL(10, 2) DEFAULT 0.00,
            discount_reason TEXT DEFAULT NULL,
            PRIMARY KEY (submission_id),
            UNIQUE KEY email_course (email, course_id),
            UNIQUE KEY tracking_token (tracking_token),
            KEY phone (phone),
            KEY course_id (course_id),
            KEY student_id (student_id)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Form submissions table creation result: ' . ($result !== false ? 'Success' : 'Failed'));

        // Create fee receipts table
        $receipts_table = $wpdb->prefix . 'boa_fee_receipts';
        error_log('BOA Activator - Creating fee receipts table manually');
        $sql = "CREATE TABLE $receipts_table (
            receipt_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            fee_id BIGINT(20) UNSIGNED NOT NULL,
            student_id BIGINT(20) UNSIGNED NOT NULL,
            file_url VARCHAR(1000) NOT NULL,
            file_hash VARCHAR(64) DEFAULT NULL,
            file_name VARCHAR(255) DEFAULT NULL,
            file_type VARCHAR(100) DEFAULT NULL,
            uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (receipt_id),
            KEY fee_id (fee_id),
            KEY student_id (student_id),
            KEY file_hash (file_hash)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Fee receipts table creation result: ' . ($result !== false ? 'Success' : 'Failed'));

        // Create live sessions table
        $sessions_table = $wpdb->prefix . 'boa_live_sessions';
        error_log('BOA Activator - Creating live sessions table manually');
        $sql = "CREATE TABLE $sessions_table (
            session_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            course_id BIGINT(20) UNSIGNED DEFAULT NULL,
            session_title VARCHAR(255) NOT NULL,
            platform VARCHAR(50) DEFAULT 'custom',
            join_url VARCHAR(1000) DEFAULT NULL,
            host_url VARCHAR(1000) DEFAULT NULL,
            start_time DATETIME NOT NULL,
            end_time DATETIME DEFAULT NULL,
            duration_minutes INT UNSIGNED DEFAULT NULL,
            instructor_name VARCHAR(255) DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'scheduled',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id),
            KEY course_id (course_id),
            KEY status (status),
            KEY start_time (start_time)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Live sessions table creation result: ' . ($result !== false ? 'Success' : 'Failed'));

        // Create live attendance table
        $attendance_table = $wpdb->prefix . 'boa_live_attendance';
        error_log('BOA Activator - Creating live attendance table manually');
        $sql = "CREATE TABLE $attendance_table (
            attendance_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id BIGINT(20) UNSIGNED NOT NULL,
            student_id BIGINT(20) UNSIGNED DEFAULT NULL,
            student_name VARCHAR(255) DEFAULT NULL,
            student_email VARCHAR(100) DEFAULT NULL,
            join_time DATETIME NOT NULL,
            leave_time DATETIME DEFAULT NULL,
            watch_minutes INT UNSIGNED DEFAULT 0,
            device_info VARCHAR(255) DEFAULT NULL,
            ip_address VARCHAR(100) DEFAULT NULL,
            status VARCHAR(20) DEFAULT 'joined',
            PRIMARY KEY (attendance_id),
            KEY session_id (session_id),
            KEY student_id (student_id),
            KEY status (status)
        ) " . $wpdb->get_charset_collate() . ";";
        $result = $wpdb->query($sql);
        error_log('BOA Activator - Live attendance table creation result: ' . ($result !== false ? 'Success' : 'Failed'));
        
        error_log('BOA Activator - All tables recreated successfully');
    }
}

// ✅ Syntax verified block end
