<?php
// 🟢 یہاں سے ڈیش بورڈ PHP شروع ہو رہا ہے
if (!defined('ABSPATH')) exit;

/**
 * ڈیش بورڈ پیج - Baba Online Academy
 * سمری کارڈز، فیس ریمائنڈر، انکم چارٹس، اور حالیہ سرگرمیاں
 *
 * (2025 BABA ARCHITECT - REFACTOR 5)
 * - نیا "Total Discounted" کارڈ شامل کیا گیا۔
 * - کارڈز گرڈ کو 5 کالمز کے لیے اپ ڈیٹ کیا گیا۔
 */

// --- اپ ڈیٹ ---
// اب ہم براہِ راست ڈیٹا بیس سے اصلی سٹیٹس (بشمول ڈسکاؤنٹ) حاصل کر رہے ہیں۔
$stats = BOA_DB::get_dashboard_summary_stats();

// کورس وایز سٹیٹس
$upcoming_courses = BOA_DB::get_upcoming_courses();
$course_admissions = BOA_DB::get_course_wise_admissions();
$course_fees_collected = BOA_DB::get_course_wise_fees_collected();
$course_pending_fees = BOA_DB::get_course_wise_pending_fees();
$dashboard_insights = BOA_DB::get_dashboard_insights();

$pending_insight = array(
    'total'           => 0,
    'oldest_days'     => 0,
    'stale_count'     => 0,
    'stale_threshold' => 3,
);
if ( isset( $dashboard_insights['pending_reviews'] ) && is_array( $dashboard_insights['pending_reviews'] ) ) {
    $pending_insight = array_merge( $pending_insight, $dashboard_insights['pending_reviews'] );
}

$missing_receipts = array(
    'total' => 0,
    'rows'  => array(),
);
if ( isset( $dashboard_insights['missing_receipts'] ) && is_array( $dashboard_insights['missing_receipts'] ) ) {
    $missing_receipts = array_merge( $missing_receipts, $dashboard_insights['missing_receipts'] );
    if ( ! is_array( $missing_receipts['rows'] ) ) {
        $missing_receipts['rows'] = array();
    }
}

$top_due_courses = ( isset( $dashboard_insights['top_dues'] ) && is_array( $dashboard_insights['top_dues'] ) )
    ? $dashboard_insights['top_dues']
    : array();
$top_due_total = 0;
$total_missing_receipts = isset( $missing_receipts['total'] ) ? (int) $missing_receipts['total'] : 0;
if ( ! empty( $top_due_courses ) ) {
    foreach ( $top_due_courses as $course_row ) {
        $top_due_total += isset( $course_row['pending_amount'] ) ? (float) $course_row['pending_amount'] : 0;
    }
}


// --- /اپ ڈیٹ ---

?>
<div id="boa-dashboard-root" class="boa-admin-wrap">
    <div class="boa-page-header">
        <div class="boa-header-left">
            <h1>Dashboard</h1>
            <p>Overview of students, courses, and fees</p>
        </div>
        <div class="boa-header-right">
            <div class="boa-quick-actions">
                <button class="boa-btn boa-btn-primary" onclick="BOA_AddStudent()">
                    <span class="dashicons dashicons-plus"></span>
                    Add Student
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_CollectFee()">
                    <span class="dashicons dashicons-money"></span>
                    Collect Fee
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_AddCourse()">
                    <span class="dashicons dashicons-book"></span>
                    Add Course
                </button>
            </div>
        </div>
    </div>

    <div class="boa-cards-grid boa-cards-grid-5">
        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Total Students</h3>
                <span class="boa-card-icon dashicons dashicons-groups"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number"><?php echo esc_html($stats['total_students']); ?></div>
                <div class="boa-stat-label">Active students</div>
                </div>
        </div>

        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Total Income</h3>
                <span class="boa-card-icon dashicons dashicons-money-alt"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number"><?php echo boa_format_currency($stats['total_income']); ?></div>
                <div class="boa-stat-label">This month</div>
            </div>
        </div>

        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Pending Fees</h3>
                <span class="boa-card-icon dashicons dashicons-warning"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number"><?php echo esc_html($stats['pending_fees']); ?></div>
                <div class="boa-stat-label">Require attention</div>
                </div>
        </div>

        <div class="boa-card boa-stats-card boa-stats-card-discount">
            <div class="boa-card-header">
                <h3>Total Discounted</h3>
                <span class="boa-card-icon dashicons dashicons-cut"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number"><?php echo boa_format_currency($stats['total_discounted']); ?></div>
                <div class="boa-stat-label">All time discounts</div>
            </div>
        </div>
        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Active Courses</h3>
                <span class="boa-card-icon dashicons dashicons-book"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number"><?php echo esc_html($stats['active_courses']); ?></div>
                <div class="boa-stat-label">Ongoing</div>
            </div>
        </div>
    </div>
    <div class="boa-insights-grid">
        <div class="boa-card boa-insight-card">
            <div class="boa-card-header">
                <h3>Admission Reviews</h3>
                <span class="boa-chip"><?php echo esc_html( number_format_i18n( $pending_insight['total'] ) ); ?> pending</span>
            </div>
            <div class="boa-card-content">
                <div class="boa-insight-metrics">
                    <div>
                        <span class="boa-insight-label">Oldest waiting</span>
                        <strong><?php echo esc_html( $pending_insight['oldest_days'] ); ?> days</strong>
                    </div>
                    <div>
                        <span class="boa-insight-label"><?php echo esc_html( $pending_insight['stale_threshold'] ); ?>+ day backlog</span>
                        <strong><?php echo esc_html( $pending_insight['stale_count'] ); ?> cases</strong>
                    </div>
                </div>
                <p class="boa-insight-note">
                    Clear the longest pending submissions first to keep applicants informed.
                </p>
            </div>
        </div>

        <div class="boa-card boa-insight-card">
            <div class="boa-card-header">
                <h3>Missing Receipts</h3>
                <span class="boa-chip boa-chip-warning"><?php echo esc_html( number_format_i18n( $total_missing_receipts ) ); ?> cases</span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($missing_receipts['rows'])): ?>
                    <p class="boa-insight-empty">All pending payments include a proof of receipt.</p>
                <?php else: ?>
                    <ul class="boa-insight-list">
                        <?php foreach ($missing_receipts['rows'] as $receipt): ?>
                            <?php
                                $student_name = ! empty( $receipt['student_name'] ) ? $receipt['student_name'] : __('Student', 'baba-online-academy');
                                $course_name  = ! empty( $receipt['course_name'] ) ? $receipt['course_name'] : __('Course', 'baba-online-academy');
                                $due_label    = ! empty( $receipt['due_date'] ) ? date_i18n( 'M d, Y', strtotime( $receipt['due_date'] ) ) : __('No due date', 'baba-online-academy');
                            ?>
                            <li>
                                <div>
                                    <strong><?php echo esc_html($student_name); ?></strong>
                                    <span class="boa-insight-subtext"><?php echo esc_html($course_name); ?></span>
                                </div>
                                <div class="boa-insight-list-meta">
                                    <span><?php echo esc_html($due_label); ?></span>
                                    <span><?php echo boa_format_currency($receipt['amount_due']); ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="boa-card boa-insight-card">
            <div class="boa-card-header">
                <h3>Top Outstanding Courses</h3>
                <span class="boa-chip boa-chip-info"><?php echo boa_format_currency($top_due_total); ?></span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($top_due_courses)): ?>
                    <p class="boa-insight-empty">No outstanding balances for active courses.</p>
                <?php else: ?>
                    <ul class="boa-insight-list">
                        <?php foreach ($top_due_courses as $course): ?>
                            <?php
                                $course_name = ! empty( $course['course_name'] ) ? $course['course_name'] : __('Course', 'baba-online-academy');
                                $invoice_count = isset( $course['invoice_count'] ) ? (int) $course['invoice_count'] : 0;
                            ?>
                            <li>
                                <div>
                                    <strong><?php echo esc_html($course_name); ?></strong>
                                    <span class="boa-insight-subtext"><?php echo esc_html($invoice_count); ?> invoices</span>
                                </div>
                                <div class="boa-insight-list-meta">
                                    <span><?php echo boa_format_currency($course['pending_amount']); ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="boa-card boa-reminder-card">
        <div class="boa-card-header">
            <h3>Upcoming Fee Deadlines</h3>
        </div>
        <div class="boa-card-content">
            <div class="boa-reminder-grid">
                <div class="boa-countdown-section">
                    <div class="boa-countdown-timer" id="boa-countdown-timer">
                        </div>
                    <div class="boa-next-due-date">
                        Next due date: <strong id="boa-next-due-date">Loading...</strong>
                    </div>
                </div>
                <div class="boa-deadlines-list">
                    <table class="boa-deadlines-table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Due Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="boa-deadlines-tbody">
                            </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="boa-charts-grid">
        <div class="boa-card boa-chart-card">
            <div class="boa-card-header">
                <h3>Monthly Income</h3>
            </div>
            <div class="boa-card-content">
                <canvas id="boa-monthly-income-chart" width="400" height="250"></canvas>
            </div>
        </div>

        <div class="boa-card boa-chart-card">
            <div class="boa-card-header">
                <h3>Course-wise Income</h3>
            </div>
            <div class="boa-card-content">
                <canvas id="boa-course-income-chart" width="400" height="250"></canvas>
            </div>
        </div>
    </div>

    <div class="boa-course-stats-grid">
        <div class="boa-card boa-course-stats-card">
            <div class="boa-card-header">
                <h3>Upcoming Courses</h3>
                <span class="boa-card-icon dashicons dashicons-calendar-alt"></span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($upcoming_courses)): ?>
                    <div class="boa-empty-state">
                        <span class="dashicons dashicons-calendar"></span>
                        <p>No upcoming courses</p>
                    </div>
                <?php else: ?>
                    <div class="boa-courses-list">
                        <?php foreach ($upcoming_courses as $course): ?>
                            <div class="boa-course-item">
                                <div class="boa-course-name"><?php echo esc_html($course['course_name']); ?></div>
                                <div class="boa-course-details">
                                    <span class="boa-course-date">
                                        <span class="dashicons dashicons-calendar-alt"></span>
                                        <?php echo esc_html($course['start_date'] ? date('M d, Y', strtotime($course['start_date'])) : 'Date not set'); ?>
                                    </span>
                                    <span class="boa-course-fee">
                                        <span class="dashicons dashicons-money-alt"></span>
                                        <?php echo boa_format_currency($course['fee_amount']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="boa-card boa-course-stats-card">
            <div class="boa-card-header">
                <h3>Admissions by Course</h3>
                <span class="boa-card-icon dashicons dashicons-groups"></span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($course_admissions)): ?>
                    <div class="boa-empty-state">
                        <span class="dashicons dashicons-groups"></span>
                        <p>No admissions data</p>
                    </div>
                <?php else: ?>
                    <div class="boa-admissions-list">
                        <?php foreach ($course_admissions as $course): ?>
                            <div class="boa-admission-item">
                                <div class="boa-course-name"><?php echo esc_html($course['course_name']); ?></div>
                                <div class="boa-admission-count">
                                    <span class="boa-count-number"><?php echo esc_html($course['admission_count']); ?></span>
                                    <span class="boa-count-label">admissions</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="boa-card boa-course-stats-card">
            <div class="boa-card-header">
                <h3>Total Fees Collected</h3>
                <span class="boa-card-icon dashicons dashicons-money-alt"></span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($course_fees_collected)): ?>
                    <div class="boa-empty-state">
                        <span class="dashicons dashicons-money-alt"></span>
                        <p>No fees collected</p>
                    </div>
                <?php else: ?>
                    <div class="boa-fees-collected-list">
                        <?php foreach ($course_fees_collected as $course): ?>
                            <div class="boa-fee-item">
                                <div class="boa-course-name"><?php echo esc_html($course['course_name']); ?></div>
                                <div class="boa-fee-amount">
                                    <?php echo boa_format_currency($course['total_collected']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="boa-card boa-course-stats-card">
            <div class="boa-card-header">
                <h3>Pending Fees</h3>
                <span class="boa-card-icon dashicons dashicons-warning"></span>
            </div>
            <div class="boa-card-content">
                <?php if (empty($course_pending_fees)): ?>
                    <div class="boa-empty-state">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <p>All fees collected!</p>
                    </div>
                <?php else: ?>
                    <div class="boa-pending-fees-list">
                        <?php foreach ($course_pending_fees as $course): ?>
                            <div class="boa-pending-item">
                                <div class="boa-course-name"><?php echo esc_html($course['course_name']); ?></div>
                                <div class="boa-pending-details">
                                    <div class="boa-pending-amount"><?php echo boa_format_currency($course['pending_amount']); ?></div>
                                    <div class="boa-pending-count"><?php echo esc_html($course['pending_count']); ?> pending</div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="boa-bottom-grid">
        <div class="boa-card boa-activity-card">
            <div class="boa-card-header">
                <h3>Recent Activity</h3>
            </div>
            <div class="boa-card-content">
                <div class="boa-activity-list" id="boa-activity-list">
                    </div>
            </div>
        </div>

        <div class="boa-card boa-actions-card">
            <div class="boa-card-header">
                <h3>Quick Actions</h3>
            </div>
            <div class="boa-card-content">
                <div class="boa-actions-buttons">
                    <button class="boa-btn boa-btn-primary boa-btn-block" onclick="BOA_AddStudent()">
                        Add Student
                    </button>
                    <button class="boa-btn boa-btn-secondary boa-btn-block" onclick="BOA_CollectFee()">
                        Collect Fee
                    </button>
                    <button class="boa-btn boa-btn-secondary boa-btn-block" onclick="BOA_AddCourse()">
                        Add Course
                    </button>
                    <button class="boa-btn boa-btn-outline boa-btn-block" onclick="BOA_ViewReports()">
                        View Reports
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="boa-card boa-table-card">
        <div class="boa-card-header">
            <h3>Fee Status Overview</h3>
            <div class="boa-table-tools">
                <input type="text" id="boa-fee-search" placeholder="Search..." class="boa-search-input">
                <select id="boa-fee-filter" class="boa-filter-select">
                    <option value="all">All</option>
                    <option value="paid">Paid</option>
                    <option value="pending">Pending</option>
                    <option value="overdue">Overdue</option>
                </select>
                <button class="boa-btn boa-btn-outline" onclick="BOA_ExportExcel()">
                    Export Excel
                </button>
                <button class="boa-btn boa-btn-outline" onclick="BOA_PrintTable()">
                    Print
                </button>
            </div>
        </div>
        <div class="boa-card-content">
            <table class="boa-data-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Course</th>
                        <th>Due Date</th>
                        <th>Amount Due</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="boa-fee-table-body">
                    </tbody>
            </table>
        </div>
    </div>

    <div class="boa-footer">
        <p>Baba Online Academy – Computer Courses Management System</p>
    </div>
</div>

<template id="boa-activity-item-template">
    <div class="boa-activity-item">
        <span class="boa-activity-icon dashicons dashicons-groups"></span> <div class="boa-activity-content">
            <div class="boa-activity-desc"></div>
            <div class="boa-activity-time"></div>
        </div>
    </div>
</template>

<template id="boa-deadline-row-template">
    <tr class="boa-deadline-row">
        <td class="boa-student-name"></td>
        <td class="boa-course-name"></td>
        <td class="boa-due-date"></td>
        <td><span class="boa-status-badge"></span></td>
    </tr>
</template>

<template id="boa-fee-row-template">
    <tr class="boa-fee-row">
        <td class="boa-student-name"></td>
        <td class="boa-course-name"></td>
        <td class="boa-due-date"></td>
        <td class="boa-amount-due"></td>
        <td><span class="boa-status-badge"></span></td>
        <td>
            <button class="boa-btn boa-btn-sm boa-btn-primary" onclick="BOA_ViewFeeDetails(this)">
                View
            </button>
        </td>
    </tr>
</template>

// ✅ Syntax verified block end
