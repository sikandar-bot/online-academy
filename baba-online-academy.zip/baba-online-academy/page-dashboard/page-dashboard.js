// 🟢 یہاں سے ڈیش بورڈ JavaScript شروع ہو رہا ہے
(function($) {
    'use strict';

    /**
     * BSSMS ڈیش بورڈ - JavaScript functionality
     * (نوٹ: اب یہ فائل 'boa_dashboard_data' آبجیکٹ سے اصلی ڈیٹا استعمال کرتی ہے)
     */

    // اگر PHP سے boa_dashboard_data نہ آیا ہو تو سیف ڈیفالٹ بنا دو
    if (typeof window.boa_dashboard_data === 'undefined') {
        console.warn('boa_dashboard_data is not defined, using safe defaults.');
        window.boa_dashboard_data = {
            ajax_url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '',
            nonce: '',
            upcoming_deadlines: [],
            income_data: { labels: [], data: [] },
            course_income: { labels: [], data: [] },
            recent_activity: [],
            fee_status_overview: []
        };
    }

    class BOA_Dashboard {
        constructor() {
            // چارٹ انسٹینسز کو محفوظ کریں تاکہ انہیں اپ ڈیٹ/ختم کیا جا سکے
            this.monthlyIncomeChart = null;
            this.courseIncomeChart = null;
            this.currency = window.boa_dashboard_data?.currency || 'PKR'; // Currency symbol
            
            this.init();
        }

        init() {
            this.initCountdownTimer();
            this.initCharts();
            this.loadDeadlines();
            this.loadRecentActivity();
            this.loadFeeTable();
            this.bindEvents();
            
            console.log('BSSMS Dashboard initialized with real data');
        }

        // === کاؤنٹ ڈاؤن ٹائمر ===
        initCountdownTimer() {
            const nextDeadline = this.getNextDeadline();
            if (!nextDeadline) {
                $('#boa-countdown-timer').html('<div class="boa-no-deadlines">No upcoming deadlines</div>');
                $('#boa-next-due-date').text('N/A');
                return;
            }

            this.updateCountdown(nextDeadline.due_date);
            this.startCountdown(nextDeadline.due_date);
        }

        getNextDeadline() {
            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            if (window.boa_dashboard_data && window.boa_dashboard_data.upcoming_deadlines && window.boa_dashboard_data.upcoming_deadlines.length > 0) {
                return window.boa_dashboard_data.upcoming_deadlines[0];
            }
            return null;
        }

        updateCountdown(dueDate) {
            const now = new Date().getTime();
            const due = new Date(dueDate).getTime();
            const distance = due - now;

            if (distance < 0) {
                $('#boa-countdown-timer').html('<div class="boa-countdown-overdue">Overdue!</div>');
                return;
            }

            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

            $('#boa-countdown-timer').html(`
                <div class="boa-countdown-item">
                    <span class="boa-countdown-number">${days}</span>
                    <span class="boa-countdown-label">Days</span>
                </div>
                <div class="boa-countdown-separator">:</div>
                <div class="boa-countdown-item">
                    <span class="boa-countdown-number">${hours}</span>
                    <span class="boa-countdown-label">Hours</span>
                </div>
                <div class="boa-countdown-separator">:</div>
                <div class="boa-countdown-item">
                    <span class="boa-countdown-number">${minutes}</span>
                    <span class="boa-countdown-label">Minutes</span>
                </div>
            `);

            $('#boa-next-due-date').text(this.formatDate(dueDate));
        }

        startCountdown(dueDate) {
            // یہ وقفہ صرف اس صورت میں سیٹ کریں اگر کوئی معقول ڈیو ڈیٹ ہو
            if (this.countdownInterval) {
                clearInterval(this.countdownInterval);
            }
            this.countdownInterval = setInterval(() => {
                this.updateCountdown(dueDate);
            }, 60000); // ہر منٹ اپڈیٹ
        }

        // === چارٹس ===
        initCharts() {
            if (typeof Chart === 'undefined') {
                console.warn('Chart.js not loaded. Skipping charts.');
                return;
            }
            this.initMonthlyIncomeChart();
            this.initCourseIncomeChart();
        }

        initMonthlyIncomeChart() {
            const ctx = document.getElementById('boa-monthly-income-chart');
            if (!ctx) return;

            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            const chartData = window.boa_dashboard_data?.income_data || {
                labels: ['No Data'],
                data: [0]
            };

            if (this.monthlyIncomeChart) this.monthlyIncomeChart.destroy();
            this.monthlyIncomeChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chartData.labels.length > 0 ? chartData.labels : ['No Data'],
                    datasets: [{
                        label: 'Monthly Income',
                        data: chartData.data.length > 0 ? chartData.data : [0],
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    // maintainAspectRatio: false, // <-- یہ لائن ہٹا دی گئی ہے
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: (context) => `Income: ${boaDashboard.currency} ${context.parsed.y.toLocaleString()}`
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: (value) => boaDashboard.currency + ' ' + value.toLocaleString()
                            }
                        }
                    }
                }
            });
        }

        initCourseIncomeChart() {
            const ctx = document.getElementById('boa-course-income-chart');
            if (!ctx) return;

            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            const chartData = window.boa_dashboard_data?.course_income || {
                labels: ['No Data'],
                data: [0]
            };

            if (this.courseIncomeChart) this.courseIncomeChart.destroy();
            this.courseIncomeChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: chartData.labels.length > 0 ? chartData.labels : ['No Data'],
                    datasets: [{
                        label: 'Course Income',
                        data: chartData.data.length > 0 ? chartData.data : [0],
                        backgroundColor: [
                            'rgba(59, 130, 246, 0.8)',
                            'rgba(245, 158, 11, 0.8)',
                            'rgba(16, 185, 129, 0.8)',
                            'rgba(139, 92, 246, 0.8)',
                            'rgba(239, 68, 68, 0.8)'
                        ],
                        borderColor: [
                            '#3b82f6',
                            '#f59e0b',
                            '#10b981',
                            '#8b5cf6',
                            '#ef4444'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    // maintainAspectRatio: false, // <-- یہ لائن ہٹا دی گئی ہے
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: (context) => `Income: ${boaDashboard.currency} ${context.parsed.y.toLocaleString()}`
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: (value) => boaDashboard.currency + ' ' + value.toLocaleString()
                            }
                        }
                    }
                }
            });
        }

        // === ڈیڈلائنز لوڈ کریں ===
        loadDeadlines() {
            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            const deadlines = window.boa_dashboard_data?.upcoming_deadlines || [];
            const tbody = $('#boa-deadlines-tbody');
            const template = document.getElementById('boa-deadline-row-template');

            tbody.empty();

            if (deadlines.length === 0) {
                tbody.append('<tr><td colspan="4" class="boa-no-data">No upcoming deadlines</td></tr>');
                return;
            }

            deadlines.forEach(deadline => {
                const clone = template.content.cloneNode(true);
                const row = clone.querySelector('.boa-deadline-row');
                
                row.querySelector('.boa-student-name').textContent = deadline.student_name || 'N/A';
                row.querySelector('.boa-course-name').textContent = deadline.course_name || 'N/A';
                row.querySelector('.boa-due-date').textContent = this.formatDate(deadline.due_date);
                
                const statusBadge = row.querySelector('.boa-status-badge');
                statusBadge.textContent = this.getStatusText(deadline.status);
                statusBadge.className = `boa-status-badge ${this.getStatusClass(deadline.status)}`;
                
                tbody.append(row);
            });
        }

        // === حالیہ سرگرمیاں ===
        loadRecentActivity() {
            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            const activities = window.boa_dashboard_data?.recent_activity || [];
            const container = $('#boa-activity-list');
            const template = document.getElementById('boa-activity-item-template');

            container.empty();

            if (activities.length === 0) {
                container.append('<div class="boa-no-data" style="padding: 0;">No recent activity</div>');
                return;
            }

            activities.forEach(activity => {
                const clone = template.content.cloneNode(true);
                const item = clone.querySelector('.boa-activity-item');
                
                item.querySelector('.boa-activity-icon').className = 'boa-activity-icon dashicons dashicons-groups';
                item.querySelector('.boa-activity-desc').textContent = `${activity.name} admitted to ${activity.course_name || 'N/A'}`;
                item.querySelector('.boa-activity-time').textContent = this.timeSince(activity.created_at);
                
                container.append(item);
            });
        }

        // === فیس ٹیبل ===
        loadFeeTable() {
            // PHP سے آنے والا اصلی ڈیٹا استعمال کریں
            const feeData = window.boa_dashboard_data?.fee_status_overview || [];
            const tbody = $('#boa-fee-table-body');
            const template = document.getElementById('boa-fee-row-template');

            tbody.empty();

            if (feeData.length === 0) {
                tbody.append('<tr><td colspan="6" class="boa-no-data">No fee records found</td></tr>');
                return;
            }

            feeData.forEach(fee => {
                const clone = template.content.cloneNode(true);
                const row = clone.querySelector('.boa-fee-row');
                
                row.querySelector('.boa-student-name').textContent = fee.student_name || 'N/A';
                row.querySelector('.boa-course-name').textContent = fee.course_name || 'N/A';
                row.querySelector('.boa-due-date').textContent = this.formatDate(fee.due_date);
                row.querySelector('.boa-amount-due').textContent = `${this.currency} ${parseFloat(fee.amount_paid).toFixed(2)}`;
                
                const statusBadge = row.querySelector('.boa-status-badge');
                statusBadge.textContent = this.getStatusText(fee.status);
                statusBadge.className = `boa-status-badge ${this.getStatusClass(fee.status)}`;
                
                tbody.append(row);
            });
        }

        // === ایونٹ بائنڈنگ ===
        bindEvents() {
            // سرچ فنکشنلٹی
            $('#boa-fee-search').on('input', (e) => {
                this.filterFeeTable(e.target.value);
            });

            // فلٹر فنکشنلٹی
            $('#boa-fee-filter').on('change', (e) => {
                this.filterFeeTableByStatus(e.target.value);
            });
        }

        filterFeeTable(searchTerm) {
            const rows = $('#boa-fee-table-body .boa-fee-row');
            const lowerTerm = searchTerm.toLowerCase();
            let visibleRows = 0;

            rows.each(function() {
                const row = $(this);
                const studentName = row.find('.boa-student-name').text().toLowerCase();
                const courseName = row.find('.boa-course-name').text().toLowerCase();
                
                if (studentName.includes(lowerTerm) || courseName.includes(lowerTerm)) {
                    row.show();
                    visibleRows++;
                } else {
                    row.hide();
                }
            });
            
            this.checkEmptyTable(rows.length, visibleRows);
        }

        filterFeeTableByStatus(status) {
            const rows = $('#boa-fee-table-body .boa-fee-row');
            let visibleRows = 0;

            if (status === 'all') {
                rows.show();
                visibleRows = rows.length;
                this.checkEmptyTable(rows.length, visibleRows);
                return;
            }

            rows.each(function() {
                const row = $(this);
                const statusBadge = row.find('.boa-status-badge');
                const rowStatus = statusBadge.text().toLowerCase();
                
                if (rowStatus === status) {
                    row.show();
                    visibleRows++;
                } else {
                    row.hide();
                }
            });
            
            this.checkEmptyTable(rows.length, visibleRows);
        }
        
        checkEmptyTable(totalRows, visibleRows) {
            const tbody = $('#boa-fee-table-body');
            // اگر کوئی 'no-data' پہلے سے ہے تو اسے ہٹائیں
            tbody.find('.boa-no-data-filter').remove();

            if (totalRows > 0 && visibleRows === 0) {
                tbody.append('<tr class="boa-no-data-filter"><td colspan="6" class="boa-no-data">No records match your filter</td></tr>');
            }
        }


        // === یوٹیلیٹی فنکشنز ===
        formatDate(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        }
        
        timeSince(dateString) {
            if (!dateString) return 'N/A';
            const seconds = Math.floor((new Date() - new Date(dateString)) / 1000);
            let interval = seconds / 31536000;
            if (interval > 1) return Math.floor(interval) + " years ago";
            interval = seconds / 2592000;
            if (interval > 1) return Math.floor(interval) + " months ago";
            interval = seconds / 86400;
            if (interval > 1) return Math.floor(interval) + " days ago";
            interval = seconds / 3600;
            if (interval > 1) return Math.floor(interval) + " hours ago";
            interval = seconds / 60;
            if (interval > 1) return Math.floor(interval) + " minutes ago";
            return Math.floor(seconds) + " seconds ago";
        }


        getStatusText(status) {
            const statusMap = {
                'paid': 'Paid',
                'pending': 'Pending',
                'overdue': 'Overdue'
            };
            return statusMap[status] || status.charAt(0).toUpperCase() + status.slice(1) || 'Unknown';
        }

        getStatusClass(status) {
            const classMap = {
                'paid': 'boa-status-paid',
                'pending': 'boa-status-pending',
                'overdue': 'boa-status-overdue'
            };
            return classMap[status] || 'boa-status-unknown';
        }
    }

    // === گلوبل فنکشنز ===
    window.BOA_AddStudent = function() {
        // سٹوڈنٹ پیج پر بھیجیں
        window.location.href = window.location.pathname + '?page=boa-students';
    };

    window.BOA_CollectFee = function() {
        // فیس پیج پر بھیجیں
        window.location.href = window.location.pathname + '?page=boa-fees';
    };

    window.BOA_AddCourse = function() {
        // کورس پیج پر بھیجیں
        window.location.href = window.location.pathname + '?page=boa-courses';
    };

    window.BOA_ViewReports = function() {
        // رپورٹس پیج پر بھیجیں
        window.location.href = window.location.pathname + '?page=boa-reports';
    };

    window.BOA_ViewFeeDetails = function(button) {
        // فیس پیج پر بھیجیں
        window.location.href = window.location.pathname + '?page=boa-fees';
    };

    window.BOA_ExportExcel = function() {
        alert('Export to Excel functionality will be implemented');
    };

    window.BOA_PrintTable = function() {
        window.print();
    };

    // === ڈاکیومینٹ ریڈی ===
    $(document).ready(function() {
        new BOA_Dashboard();
    });

})(jQuery);
// ✅ Syntax verified block end