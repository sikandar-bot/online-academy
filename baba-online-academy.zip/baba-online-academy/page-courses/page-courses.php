<?php
// 🟢 یہاں سے Courses Management PHP شروع ہو رہا ہے
if (!defined('ABSPATH')) exit;

/**
 * Courses Management پیج - BSSMS Computer Courses Management System
 * کورسز مینجمنٹ، کیٹیگریز، اور انکم رپورٹس
 *
 * پہلے یہ سب کچھ BOA_Courses_Page کلاس کے اندر تھا اور
 * render_courses_page() method کے ذریعے آؤٹ پُٹ آتا تھا۔
 * اب اسے pure template بنا دیا گیا ہے تاکہ baba-online-academy.php
 * جب اسے include کرے تو سیدھا HTML رینڈر ہو جائے۔
 */

/**
 * Helper function صرف اسی فائل کے لیے
 * (پہلے یہ private function تھا: get_categories())
 */
if ( ! function_exists( 'boa_courses_get_categories' ) ) {
    function boa_courses_get_categories() {
        global $wpdb;
        if ( ! isset( $wpdb ) ) {
            return array();
        }

        return $wpdb->get_results("
            SELECT category_id, category_name 
            FROM {$wpdb->prefix}boa_categories 
            ORDER BY category_name
        ", ARRAY_A);
    }
}
?>

<div id="boa-courses-root">
    <!-- === پیج ہیڈر === -->
    <div class="boa-page-header">
        <div class="boa-header-left">
            <h1>Courses Management</h1>
            <p>Manage courses, details, categories, and profitability</p>
        </div>
        <div class="boa-header-right">
            <div class="boa-toolbar-actions">
                <button class="boa-btn boa-btn-primary" onclick="BOA_OpenAddCourseModal()">
                    <span class="dashicons dashicons-plus"></span>
                    Add Course
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_OpenImportModal()">
                    <span class="dashicons dashicons-upload"></span>
                    Import
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_ExportCourses()">
                    <span class="dashicons dashicons-download"></span>
                    Export
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_GenerateDemoData()">
                    <span class="dashicons dashicons-database"></span>
                    Demo Data
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_ExportExcel()">
                    <span class="dashicons dashicons-media-spreadsheet"></span>
                    Excel Download
                </button>
                <button class="boa-btn boa-btn-secondary" onclick="BOA_PrintCourses()">
                    <span class="dashicons dashicons-printer"></span>
                    Print
                </button>
            </div>
        </div>
    </div>

    <!-- === سمری کارڈز === -->
    <div class="boa-cards-grid">
        <!-- ٹوٹل کورسز -->
        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Total Courses</h3>
                <span class="boa-card-icon dashicons dashicons-book"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number" id="boa-total-courses">0</div>
                <div class="boa-stat-label">All courses</div>
            </div>
        </div>

        <!-- ایکٹو کورسز -->
        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Active Courses</h3>
                <span class="boa-card-icon dashicons dashicons-yes"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number" id="boa-active-courses">0</div>
                <div class="boa-stat-label">Currently available</div>
                <span class="boa-badge boa-badge-success">Active</span>
            </div>
        </div>

        <!-- ان ایکٹو کورسز -->
        <div class="boa-card boa-stats-card">
            <div class="boa-card-header">
                <h3>Inactive Courses</h3>
                <span class="boa-card-icon dashicons dashicons-no"></span>
            </div>
            <div class="boa-card-content">
                <div class="boa-stat-number" id="boa-inactive-courses">0</div>
                <div class="boa-stat-label">Not available</div>
                <span class="boa-badge boa-badge-gray">Inactive</span>
            </div>
        </div>
    </div>

    <!-- === مین سیکشن === -->
    <div class="boa-main-layout">
        <!-- بائیں کالم - کورسز ٹیبل -->
        <div class="boa-main-content">
            <!-- ٹیبل کنٹرولز -->
            <div class="boa-table-controls">
                <div class="boa-search-box">
                    <input type="text" id="boa-courses-search" placeholder="Search by course name or ID" class="boa-search-input">
                    <span class="dashicons dashicons-search"></span>
                </div>
                <select id="boa-category-filter" class="boa-filter-select">
                    <option value="">All Categories</option>
                    <?php foreach ( boa_courses_get_categories() as $category ): ?>
                        <option value="<?php echo esc_attr( $category['category_id'] ); ?>">
                            <?php echo esc_html( $category['category_name'] ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select id="boa-status-filter" class="boa-filter-select">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <select id="boa-duration-filter" class="boa-filter-select">
                    <option value="">All Durations</option>
                    <option value="1-3">1-3 Months</option>
                    <option value="3-6">3-6 Months</option>
                    <option value="6-12">6-12 Months</option>
                    <option value="12+">12+ Months</option>
                </select>
                <a href="#" class="boa-reset-link" onclick="BOA_ResetFilters()">Reset Filters</a>
                <div class="boa-mini-actions">
                    <button class="boa-btn boa-btn-outline boa-btn-sm" onclick="BOA_ExportExcel()">
                        Export Excel
                    </button>
                    <button class="boa-btn boa-btn-outline boa-btn-sm" onclick="BOA_PrintCourses()">
                        Print
                    </button>
                </div>
            </div>

            <!-- کورسز ٹیبل -->
            <div class="boa-card boa-table-card">
                <div class="boa-card-header">
                    <h3>Courses List</h3>
                </div>
                <div class="boa-card-content">
                    <table class="boa-data-table" id="boa-courses-table">
                        <thead>
                            <tr>
                                <th width="30">
                                    <input type="checkbox" id="boa-select-all" onchange="BOA_ToggleSelectAll(this)">
                                </th>
                                <th>Course ID</th>
                                <th>Course Name</th>
                                <th>Category</th>
                                <th>Duration</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Fee Amount</th>
                                <th>Status</th>
                                <th width="120">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="boa-courses-tbody">
                            <!-- JS سے بھرا جائے گا -->
                        </tbody>
                    </table>

                    <!-- پیجینیشن -->
                    <div class="boa-pagination">
                        <div class="boa-pagination-info">
                            Showing <span id="boa-showing-from">1</span>-<span id="boa-showing-to">10</span> 
                            of <span id="boa-total-records">0</span> courses
                        </div>
                        <div class="boa-pagination-controls">
                            <select id="boa-rows-per-page" class="boa-rows-select" onchange="BOA_ChangeRowsPerPage(this.value)">
                                <option value="10">10 rows</option>
                                <option value="25">25 rows</option>
                                <option value="50">50 rows</option>
                                <option value="100">100 rows</option>
                            </select>
                            <div class="boa-page-numbers" id="boa-page-numbers">
                                <!-- JS سے بھرا جائے گا -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- دائیں کالم - کیٹیگریز اور سنیپ شاٹ -->
        <div class="boa-sidebar">
            <!-- کوئیک ایکشنز -->
            <div class="boa-card boa-actions-card">
                <div class="boa-card-header">
                    <h3>Quick Actions</h3>
                </div>
                <div class="boa-card-content">
                    <div class="boa-actions-buttons">
                        <button class="boa-btn boa-btn-primary boa-btn-block" onclick="BOA_OpenAddCourseModal()">
                            Add Course
                        </button>
                        <button class="boa-btn boa-btn-secondary boa-btn-block" onclick="BOA_ViewReports()">
                            View Reports
                        </button>
                        <button class="boa-btn boa-btn-outline boa-btn-block" onclick="BOA_ManageCategories()">
                            Manage Categories
                        </button>
                    </div>
                </div>
            </div>

            <!-- کورس کیٹیگریز -->
            <div class="boa-card boa-categories-card">
                <div class="boa-card-header">
                    <h3>Course Categories</h3>
                </div>
                <div class="boa-card-content">
                    <div class="boa-categories-list" id="boa-categories-list">
                        <!-- JS سے بھرا جائے گا -->
                    </div>
                    <div class="boa-add-category">
                        <div class="boa-input-group">
                            <input type="text" id="boa-new-category" placeholder="New category name" class="boa-form-input">
                            <button class="boa-btn boa-btn-primary" onclick="BOA_AddCategory()">
                                <span class="dashicons dashicons-plus"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- کورس سنیپ شاٹ -->
            <div class="boa-card boa-snapshot-card">
                <div class="boa-card-header">
                    <h3>Courses by Category</h3>
                </div>
                <div class="boa-card-content">
                    <div class="boa-chart-container">
                        <canvas id="boa-categories-chart" width="200" height="200"></canvas>
                    </div>
                    <div class="boa-popular-categories" id="boa-popular-categories">
                        <!-- JS سے بھرا جائے گا -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- === فوٹر === -->
    <div class="boa-footer">
        <p>BSSMS – Computer Courses Management System</p>
    </div>
</div>

<!-- === کورس ڈیٹیلز سلیڈ اوور === -->
<div id="boa-course-details" class="boa-slide-over">
    <div class="boa-slide-over-content">
        <div class="boa-slide-over-header">
            <h3 id="boa-course-detail-title">Course Details</h3>
            <button class="boa-close-btn" onclick="BOA_CloseCourseDetails()">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-slide-over-body">
            <div class="boa-course-tabs">
                <button class="boa-tab-btn boa-tab-active" data-tab="overview">Overview</button>
                <button class="boa-tab-btn" data-tab="students">Students Enrolled</button>
                <button class="boa-tab-btn" data-tab="income">Income Report</button>
            </div>

            <!-- اوورویو ٹیب -->
            <div id="boa-tab-overview" class="boa-tab-content boa-tab-active">
                <div class="boa-course-overview">
                    <div class="boa-course-basic-info">
                        <div class="boa-info-row">
                            <label>Course Name:</label>
                            <span id="boa-detail-name">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>Category:</label>
                            <span id="boa-detail-category">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>Duration:</label>
                            <span id="boa-detail-duration">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>Start Date:</label>
                            <span id="boa-detail-start-date">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>End Date:</label>
                            <span id="boa-detail-end-date">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>Fee Amount:</label>
                            <span id="boa-detail-fee">-</span>
                        </div>
                        <div class="boa-info-row">
                            <label>Status:</label>
                            <span id="boa-detail-status-badge" class="boa-status-badge">-</span>
                        </div>
                    </div>
                    <div class="boa-course-description">
                        <label>Description:</label>
                        <div class="boa-description-content" id="boa-detail-description">
                            <!-- ڈسکرپشن کونٹینٹ -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- سٹوڈنٹس انرولڈ ٹیب -->
            <div id="boa-tab-students" class="boa-tab-content">
                <div class="boa-students-controls">
                    <div class="boa-search-box">
                        <input type="text" id="boa-students-search" placeholder="Search students..." class="boa-search-input">
                        <span class="dashicons dashicons-search"></span>
                    </div>
                    <select id="boa-students-status-filter" class="boa-filter-select">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <table class="boa-data-table boa-students-table">
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Admission Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="boa-course-students-tbody">
                        <!-- JS سے بھرا جائے گا -->
                    </tbody>
                </table>
            </div>

            <!-- انکم رپورٹ ٹیب -->
            <div id="boa-tab-income" class="boa-tab-content">
                <div class="boa-income-summary">
                    <div class="boa-income-stats">
                        <div class="boa-income-stat">
                            <div class="boa-stat-value" id="boa-total-income"><?php echo boa_get_currency_symbol(); ?> 0</div>
                            <div class="boa-stat-label">Total Earned</div>
                        </div>
                        <div class="boa-income-stat">
                            <div class="boa-stat-value" id="boa-avg-monthly"><?php echo boa_get_currency_symbol(); ?> 0</div>
                            <div class="boa-stat-label">Avg Monthly</div>
                        </div>
                    </div>
                    <div class="boa-income-chart">
                        <canvas id="boa-income-chart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- === ایڈ/ایڈٹ کورس موڈل === -->
<div id="boa-course-modal" class="boa-modal">
    <div class="boa-modal-content">
        <div class="boa-modal-header">
            <h3 id="boa-modal-title">Add Course</h3>
            <button class="boa-close-btn" onclick="BOA_CloseCourseModal()">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-modal-body">
            <form id="boa-course-form" onsubmit="return BOA_SaveCourse(event)">
                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-course-name">Course Name *</label>
                        <input type="text" id="boa-course-name" name="course_name" required class="boa-form-input" placeholder="e.g., Web Development">
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-course-category">Category *</label>
                        <select id="boa-course-category" name="category_id" required class="boa-form-select">
                            <option value="">Select Category</option>
                            <?php foreach ( boa_courses_get_categories() as $category ): ?>
                                <option value="<?php echo esc_attr( $category['category_id'] ); ?>">
                                    <?php echo esc_html( $category['category_name'] ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-course-fee">Fee Amount *</label>
                        <div class="boa-input-with-symbol">
                            <span class="boa-input-symbol"><?php echo boa_get_currency_symbol(); ?></span>
                            <input type="number" id="boa-course-fee" name="fee_amount" required class="boa-form-input" step="0.01" min="0" placeholder="0.00">
                        </div>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-course-duration">Duration *</label>
                        <input type="text" id="boa-course-duration" name="duration" required class="boa-form-input" placeholder="e.g., 3 Months">
                    </div>
                </div>

                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-course-start-date">Start Date</label>
                        <input type="date" id="boa-course-start-date" name="start_date" class="boa-form-input">
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-course-end-date">End Date</label>
                        <input type="date" id="boa-course-end-date" name="end_date" class="boa-form-input">
                    </div>
                </div>

                <div class="boa-form-row">
                    <div class="boa-form-group boa-full-width">
                        <label for="boa-course-description">Description</label>
                        <textarea id="boa-course-description" name="description" class="boa-form-textarea" rows="4" placeholder="Course description..."></textarea>
                    </div>
                </div>

                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-course-status">Status *</label>
                        <select id="boa-course-status" name="status" required class="boa-form-select">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-course-id">Course ID</label>
                        <input type="text" id="boa-course-id" name="course_id" class="boa-form-input" readonly>
                        <small>Auto-generated</small>
                    </div>
                </div>
            </form>
        </div>
        <div class="boa-modal-footer">
            <button type="button" class="boa-btn boa-btn-secondary" onclick="BOA_CloseCourseModal()">Cancel</button>
            <button type="submit" form="boa-course-form" class="boa-btn boa-btn-primary">Save Course</button>
        </div>
    </div>
</div>

<!-- === کیٹیگری مینجمنٹ موڈل === -->
<div id="boa-categories-modal" class="boa-modal">
    <div class="boa-modal-content">
        <div class="boa-modal-header">
            <h3>Manage Categories</h3>
            <button class="boa-close-btn" onclick="BOA_CloseCategoriesModal()">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-modal-body">
            <div class="boa-categories-management">
                <div class="boa-add-category-form">
                    <h4>Add New Category</h4>
                    <div class="boa-input-group">
                        <input type="text" id="boa-manage-new-category" placeholder="Category name" class="boa-form-input">
                        <button class="boa-btn boa-btn-primary" onclick="BOA_AddNewCategory()">
                            Add Category
                        </button>
                    </div>
                </div>
                <div class="boa-categories-table">
                    <h4>Existing Categories</h4>
                    <table class="boa-data-table">
                        <thead>
                            <tr>
                                <th>Category Name</th>
                                <th>Courses Count</th>
                                <th width="100">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="boa-manage-categories-tbody">
                            <!-- JS سے بھرا جائے گا -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="boa-modal-footer">
            <button class="boa-btn boa-btn-primary" onclick="BOA_CloseCategoriesModal()">Done</button>
        </div>
    </div>
</div>

<!-- === ٹیمپلیٹس === -->
<template id="boa-course-row-template">
    <tr class="boa-course-row">
        <td><input type="checkbox" class="boa-course-checkbox" onchange="BOA_UpdateBulkActions()"></td>
        <td class="boa-course-id"></td>
        <td class="boa-course-name"></td>
        <td class="boa-course-category"></td>
        <td class="boa-course-duration"></td>
        <td class="boa-course-start-date"></td>
        <td class="boa-course-end-date"></td>
        <td class="boa-course-fee"></td>
        <td><span class="boa-status-badge"></span></td>
        <td>
            <div class="boa-action-buttons">
                <button class="boa-btn-icon boa-btn-view" onclick="BOA_ViewCourse(this)" title="View Details">
                    <span class="dashicons dashicons-visibility"></span>
                </button>
                <button class="boa-btn-icon boa-btn-edit" onclick="BOA_EditCourse(this)" title="Edit">
                    <span class="dashicons dashicons-edit"></span>
                </button>
                <button class="boa-btn-icon boa-btn-delete" onclick="BOA_DeleteCourse(this)" title="Delete">
                    <span class="dashicons dashicons-trash"></span>
                </button>
            </div>
        </td>
    </tr>
</template>

<template id="boa-category-item-template">
    <div class="boa-category-item">
        <span class="boa-category-name"></span>
        <div class="boa-category-actions">
            <button class="boa-btn-icon" onclick="BOA_EditCategory(this)" title="Edit">
                <span class="dashicons dashicons-edit"></span>
            </button>
            <button class="boa-btn-icon" onclick="BOA_DeleteCategory(this)" title="Delete">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
    </div>
</template>

<template id="boa-student-row-template">
    <tr class="boa-student-row">
        <td class="boa-student-name"></td>
        <td class="boa-admission-date"></td>
        <td><span class="boa-status-badge"></span></td>
    </tr>
</template>

<template id="boa-popular-category-template">
    <div class="boa-popular-category">
        <span class="boa-category-name"></span>
        <span class="boa-courses-count"></span>
    </div>
</template>

<template id="boa-manage-category-template">
    <tr class="boa-manage-category-row">
        <td class="boa-category-name"></td>
        <td class="boa-courses-count"></td>
        <td>
            <div class="boa-action-buttons">
                <button class="boa-btn-icon boa-btn-edit" onclick="BOA_EditManageCategory(this)" title="Edit">
                    <span class="dashicons dashicons-edit"></span>
                </button>
                <button class="boa-btn-icon boa-btn-delete" onclick="BOA_DeleteManageCategory(this)" title="Delete">
                    <span class="dashicons dashicons-trash"></span>
                </button>
            </div>
        </td>
    </tr>
</template>
