<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div id="boa-live-sessions-root" class="boa-admin-wrap">
    <div class="boa-page-header">
        <div class="boa-header-left">
            <h1><?php esc_html_e( 'Live Sessions', 'baba-online-academy' ); ?></h1>
            <p><?php esc_html_e( 'Plan online classes, share join links, اور حاضری کو خودکار طور پر ٹریک کریں۔', 'baba-online-academy' ); ?></p>
        </div>
        <div class="boa-header-right">
            <button class="boa-btn boa-btn-primary" id="boa-session-add-btn">
                <span class="dashicons dashicons-plus-alt2"></span>
                <?php esc_html_e( 'New Session', 'baba-online-academy' ); ?>
            </button>
        </div>
    </div>

    <div class="boa-card">
        <div class="boa-card-header">
            <h3><?php esc_html_e( 'Scheduled Sessions', 'baba-online-academy' ); ?></h3>
            <div class="boa-session-filters">
                <select id="boa-session-course-filter">
                    <option value=""><?php esc_html_e( 'All Courses', 'baba-online-academy' ); ?></option>
                </select>
                <select id="boa-session-status-filter">
                    <option value=""><?php esc_html_e( 'All Statuses', 'baba-online-academy' ); ?></option>
                    <option value="scheduled"><?php esc_html_e( 'Scheduled', 'baba-online-academy' ); ?></option>
                    <option value="completed"><?php esc_html_e( 'Completed', 'baba-online-academy' ); ?></option>
                    <option value="cancelled"><?php esc_html_e( 'Cancelled', 'baba-online-academy' ); ?></option>
                </select>
                <input type="search" id="boa-session-search" placeholder="<?php esc_attr_e( 'Search sessions…', 'baba-online-academy' ); ?>">
                <button class="boa-btn boa-btn-secondary" id="boa-session-refresh">
                    <span class="dashicons dashicons-update"></span>
                    <?php esc_html_e( 'Refresh', 'baba-online-academy' ); ?>
                </button>
            </div>
        </div>
        <div class="boa-card-content">
            <table class="boa-data-table" id="boa-live-sessions-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Session', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Course', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Start Time', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Instructor', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'baba-online-academy' ); ?></th>
                        <th style="width:160px;"><?php esc_html_e( 'Actions', 'baba-online-academy' ); ?></th>
                    </tr>
                </thead>
                <tbody id="boa-live-sessions-tbody">
                    <tr><td colspan="6"><?php esc_html_e( 'Loading sessions…', 'baba-online-academy' ); ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="boa-session-modal" class="boa-modal">
    <div class="boa-modal-content boa-modal-large">
        <div class="boa-modal-header">
            <h3 id="boa-session-modal-title"><?php esc_html_e( 'Create Live Session', 'baba-online-academy' ); ?></h3>
            <button class="boa-close-btn" id="boa-session-modal-close">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-modal-body">
            <form id="boa-session-form">
                <input type="hidden" id="boa-session-id">
                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-session-title"><?php esc_html_e( 'Session Title *', 'baba-online-academy' ); ?></label>
                        <input type="text" id="boa-session-title" required>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-course"><?php esc_html_e( 'Course', 'baba-online-academy' ); ?></label>
                        <select id="boa-session-course"></select>
                    </div>
                </div>
                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-session-start"><?php esc_html_e( 'Start Time *', 'baba-online-academy' ); ?></label>
                        <input type="datetime-local" id="boa-session-start" required>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-end"><?php esc_html_e( 'End Time', 'baba-online-academy' ); ?></label>
                        <input type="datetime-local" id="boa-session-end">
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-instructor"><?php esc_html_e( 'Instructor', 'baba-online-academy' ); ?></label>
                        <input type="text" id="boa-session-instructor" placeholder="<?php esc_attr_e( 'Optional', 'baba-online-academy' ); ?>">
                    </div>
                </div>
                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-session-platform"><?php esc_html_e( 'Platform', 'baba-online-academy' ); ?></label>
                        <input type="text" id="boa-session-platform" placeholder="Zoom / Google Meet / Custom">
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-join"><?php esc_html_e( 'Join URL', 'baba-online-academy' ); ?></label>
                        <input type="url" id="boa-session-join" placeholder="https://">
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-host"><?php esc_html_e( 'Host URL', 'baba-online-academy' ); ?></label>
                        <input type="url" id="boa-session-host" placeholder="https://">
                    </div>
                </div>
                <div class="boa-form-row">
                    <div class="boa-form-group">
                        <label for="boa-session-status"><?php esc_html_e( 'Status', 'baba-online-academy' ); ?></label>
                        <select id="boa-session-status">
                            <option value="scheduled"><?php esc_html_e( 'Scheduled', 'baba-online-academy' ); ?></option>
                            <option value="completed"><?php esc_html_e( 'Completed', 'baba-online-academy' ); ?></option>
                            <option value="cancelled"><?php esc_html_e( 'Cancelled', 'baba-online-academy' ); ?></option>
                        </select>
                    </div>
                    <div class="boa-form-group">
                        <label for="boa-session-duration"><?php esc_html_e( 'Duration (minutes)', 'baba-online-academy' ); ?></label>
                        <input type="number" id="boa-session-duration" min="15" step="5" placeholder="60">
                    </div>
                </div>
            </form>
        </div>
        <div class="boa-modal-footer">
            <button class="boa-btn boa-btn-secondary" id="boa-session-cancel"><?php esc_html_e( 'Cancel', 'baba-online-academy' ); ?></button>
            <button class="boa-btn boa-btn-primary" id="boa-session-save"><?php esc_html_e( 'Save Session', 'baba-online-academy' ); ?></button>
        </div>
    </div>
</div>

<div id="boa-attendance-modal" class="boa-modal">
    <div class="boa-modal-content">
        <div class="boa-modal-header">
            <h3><?php esc_html_e( 'Attendance Log', 'baba-online-academy' ); ?></h3>
            <button class="boa-close-btn" id="boa-attendance-close">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="boa-modal-body">
            <table class="boa-data-table" id="boa-attendance-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Student', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Join', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Leave', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Watch (min)', 'baba-online-academy' ); ?></th>
                        <th><?php esc_html_e( 'Device / IP', 'baba-online-academy' ); ?></th>
                    </tr>
                </thead>
                <tbody id="boa-attendance-tbody">
                    <tr><td colspan="5"><?php esc_html_e( 'Loading...', 'baba-online-academy' ); ?></td></tr>
                </tbody>
            </table>
        </div>
        <div class="boa-modal-footer">
            <button class="boa-btn boa-btn-secondary" id="boa-attendance-done"><?php esc_html_e( 'Close', 'baba-online-academy' ); ?></button>
        </div>
    </div>
</div>
